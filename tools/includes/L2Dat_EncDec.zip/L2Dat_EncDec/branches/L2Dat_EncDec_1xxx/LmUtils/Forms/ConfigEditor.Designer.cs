﻿namespace LmUtils
{
    partial class ConfigEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose (bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent ()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager (typeof (ConfigEditor));
			this.but_ok = new System.Windows.Forms.Button ();
			this.but_cancel = new System.Windows.Forms.Button ();
			this.property_grid = new System.Windows.Forms.PropertyGrid ();
			this.pictureBox1 = new System.Windows.Forms.PictureBox ();
			this.but_defaults = new System.Windows.Forms.Button ();
			((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).BeginInit ();
			this.SuspendLayout ();
			// 
			// but_ok
			// 
			this.but_ok.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.but_ok.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.but_ok.Location = new System.Drawing.Point (354, 479);
			this.but_ok.Name = "but_ok";
			this.but_ok.Size = new System.Drawing.Size (75, 23);
			this.but_ok.TabIndex = 2;
			this.but_ok.Text = "OK";
			this.but_ok.Click += new System.EventHandler (this.but_ok_Click);
			// 
			// but_cancel
			// 
			this.but_cancel.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.but_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.but_cancel.Location = new System.Drawing.Point (436, 479);
			this.but_cancel.Name = "but_cancel";
			this.but_cancel.Size = new System.Drawing.Size (75, 23);
			this.but_cancel.TabIndex = 3;
			this.but_cancel.Text = "Cancel";
			this.but_cancel.Click += new System.EventHandler (this.but_cancel_Click);
			// 
			// property_grid
			// 
			this.property_grid.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.property_grid.Location = new System.Drawing.Point (77, 13);
			this.property_grid.Margin = new System.Windows.Forms.Padding (12, 3, 8, 12);
			this.property_grid.Name = "property_grid";
			this.property_grid.Size = new System.Drawing.Size (429, 441);
			this.property_grid.TabIndex = 0;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.pictureBox1.Image = global::LmUtils.Properties.Resources.Preferences_48;
			this.pictureBox1.Location = new System.Drawing.Point (13, 13);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size (48, 48);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 11;
			this.pictureBox1.TabStop = false;
			// 
			// but_defaults
			// 
			this.but_defaults.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.but_defaults.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.but_defaults.Location = new System.Drawing.Point (400, 9);
			this.but_defaults.Name = "but_defaults";
			this.but_defaults.Size = new System.Drawing.Size (106, 23);
			this.but_defaults.TabIndex = 4;
			this.but_defaults.Text = "Set defaults";
			this.but_defaults.Click += new System.EventHandler (this.but_defaults_Click);
			// 
			// ConfigEditor
			// 
			this.AcceptButton = this.but_ok;
			this.CancelButton = this.but_cancel;
			this.ClientSize = new System.Drawing.Size (523, 514);
			this.Controls.Add (this.but_defaults);
			this.Controls.Add (this.pictureBox1);
			this.Controls.Add (this.but_ok);
			this.Controls.Add (this.but_cancel);
			this.Controls.Add (this.property_grid);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon) (resources.GetObject ("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size (220, 250);
			this.Name = "ConfigEditor";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Configuration";
			((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).EndInit ();
			this.ResumeLayout (false);
			this.PerformLayout ();

		}

        #endregion

        private System.Windows.Forms.Button but_ok;
        private System.Windows.Forms.Button but_cancel;
		private System.Windows.Forms.PropertyGrid property_grid;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button but_defaults;

	}
}