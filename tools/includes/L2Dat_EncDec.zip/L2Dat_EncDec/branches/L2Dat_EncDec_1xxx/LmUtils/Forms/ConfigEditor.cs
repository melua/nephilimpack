﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace LmUtils
{
	public partial class ConfigEditor : Form
	{
		private Config config;

		public ConfigEditor (Config config)
		{
			InitializeComponent ();

			this.config = config;
			this.property_grid.SelectedObject = this.config;
		}

		private void but_ok_Click(object sender, EventArgs e)
		{
			this.config.Save ();
			this.Close ();
		}

		private void but_cancel_Click(object sender, EventArgs e)
		{
			//this.config.Reload ();
			this.Close ();
		}

		private void but_defaults_Click(object sender, EventArgs e)
		{
			this.config.ResetDefaults ();
			this.property_grid.SelectedObject = this.config;
		}
	}
}