﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Collections;
using System.Drawing.Design;

#endregion

namespace LmUtils
{
	public class PropertyTable : CustomTypeDescriptor
	{
		#region Property class implementation
		public class Property
		{
			public string name;
			public string title;
			public string category;
			public string description;
			public object default_val;
			public object val;
			public UITypeEditor editor;
			public bool read_only;

			public Property (string name, string title, string category) : this (name, title, category, null, null, null, false)
			{
			}
			public Property (string name, string title, string category, object val) : this (name, title, category, null, val, null, false)
			{
			}
			public Property (string name, string title, string category, string description, object val) : this (name, title, category, description, val, null, false)
			{
			}
			public Property (string name, string title, string category, string description, object val, UITypeEditor editor, bool read_only)
			{
				this.name = name;
				this.title = title;
				this.category = category;
				this.description = description;
				this.val = val;
				this.default_val = val;
				this.editor = editor;
				this.read_only = read_only;
			}
		}
		#endregion
		#region PropertyDescription class implementation
		private class PropertyDescription : System.ComponentModel.PropertyDescriptor
		{
			public PropertyTable table;
			public Property prop;

			public PropertyDescription (PropertyTable table, Property prop, Attribute[] attrs) : base (prop.title, attrs)
			{
				this.table = table;
				this.prop = prop;
			}

			public override bool CanResetValue (object component)
			{
				if (this.prop.default_val == null)
					return false;
				else
					return this.GetValue (component).Equals (this.prop.default_val);
			}
			public override Type ComponentType
			{
				get { return this.prop.val.GetType (); }
			}


			public override object GetValue (object component)
			{
				return this.prop.val;
			}
			public override bool IsReadOnly
			{
				get { return this.prop.read_only; }
			}

			public override Type PropertyType
			{
				get { return this.prop.val.GetType (); }
			}


			public override void ResetValue (object component)
			{
				this.SetValue (component, this.prop.default_val);
			}

			public override void SetValue (object component, object value)
			{
				this.prop.val = value;
			}

			public override bool ShouldSerializeValue (object component)
			{
				object val = this.GetValue (component);
				if (this.prop.default_val == null && val == null)
					return false;
				else
					return !val.Equals (this.prop.default_val);
			}
		}
		#endregion

		public Hashtable props;

		#region Constructors, destructor...
		public PropertyTable ()
		{
			this.props = new Hashtable ();
		}
		#endregion

		#region Accessors

		/// <summary>
		/// Get/set
		/// </summary>
		/// <param name="name">property name</param>
		/// <returns>PropertyTable.Property</returns>
		public object this[string name]
		{
			get
			{
				if (!this.props.ContainsKey (name))
					return null;

				return (this.props[name] as PropertyTable.Property);
			}
			set
            {
				if (value is Property)
				{
					if (!this.props.ContainsKey (name))
						this.props.Add (name, value);
					else
						this.props[name] = value;
				}
				else
				{
					if (!this.props.ContainsKey (name))
						throw new ApplicationException ("Property table does not contains property '" + name + "'");

					(this.props[name] as Property).val = value;
				}
			}
        }
		#endregion

		#region Other functions
		public void Add (Property property)
		{
			this[property.name] = property;
		}
		#endregion

		#region CustomTypeDescriptor implementation
		public override PropertyDescriptorCollection GetProperties (Attribute[] attributes)
		{
			ArrayList props_list = new ArrayList ();
			foreach (Property prop in this.props.Values)
			{
				ArrayList attrs = new ArrayList ();
				if (prop.category != null)
					attrs.Add (new CategoryAttribute (prop.category));

				if (prop.description != null)
					attrs.Add (new DescriptionAttribute (prop.description));

				if (prop.editor != null)
					attrs.Add (new EditorAttribute (prop.editor.GetType ().AssemblyQualifiedName, typeof (UITypeEditor)));

				props_list.Add (new PropertyDescription (this, prop, (Attribute[])attrs.ToArray (typeof (Attribute))));
			}

			return new PropertyDescriptorCollection ((PropertyDescriptor[])props_list.ToArray (typeof (PropertyDescriptor)));
		}

		#endregion
	}
}
