﻿using System;
using System.Threading;

namespace LmUtils
{
	public class DateTimePeriod
	{
		#region Accessors

		#region Days
		protected int days;

		/// <summary>
		/// Gets or sets days interval (if <see cref="DateTimePeriod.UseDays"/> is true)
		/// </summary>
		public int Days
		{
			get
			{
				return this.days;
			}
			set
			{
				this.days = value;
			}
		}
		#endregion

		#region UseDays
		protected bool use_days;

		/// <summary>
		/// Gets or sets using day-based period or only time-based period?
		/// </summary>
		public bool UseDays
		{
			get
			{
				return this.use_days;
			}
			set
			{
				this.use_days = value;
			}
		}
		#endregion

		#region Hours
		protected int hours;

		/// <summary>
		/// Gets or sets hours intervals
		/// </summary>
		public int Hours
		{
			get
			{
				return this.hours;
			}
			set
			{
				this.hours = value;
			}
		}
		#endregion

		#region Minutes
		protected int minutes;

		/// <summary>
		/// Gets or sets minutes interval
		/// </summary>
		public int Minutes
		{
			get
			{
				return this.minutes;
			}
			set
			{
				this.minutes = value;
			}
		}
		#endregion

		#region Seconds
		protected int seconds;

		/// <summary>
		/// Gets or sets seconds interval
		/// </summary>
		public int Seconds
		{
			get
			{
				return this.seconds;
			}
			set
			{
				this.seconds = value;
			}
		}
		#endregion

		#region Start
		protected DateTime start;

		/// <summary>
		/// Gets or sets start date (or datetime if UseDays is false)
		/// </summary>
		public DateTime Start
		{
			get
			{
				return this.start;
			}
			set
			{
				this.start = value;
			}
		}
		#endregion

		#region IsEmpty

		/// <summary>
		/// Gets { this.days == 0 && this.hours == 0 && this.minutes == 0 && this.seconds == 0 }
		/// </summary>
		public bool IsEmpty
		{
			get
			{
				return (this.use_days && this.days == 0) ||
						(!this.use_days && this.hours == 0 && this.minutes == 0 && this.seconds == 0);
			}
		}
		#endregion

		#region IsTimeEmpty

		/// <summary>
		/// Gets { this.hours == 0 && this.minutes == 0 && this.seconds == 0 }
		/// </summary>
		public bool IsTimeEmpty
		{
			get
			{
				return (this.hours == 0 && this.minutes == 0 && this.seconds == 0);
			}
		}
		#endregion

		#region Period

		/// <summary>
		/// Gets time period
		/// </summary>
		public TimeSpan Period
		{
			get
			{
				if (this.use_days)
					return new TimeSpan (this.days, 0, 0, 0);
				else
					return new TimeSpan (0, this.hours, this.minutes, this.seconds);
			}
		}
		#endregion

		#region Ticks

		/// <summary>
		/// Gets period time ticks
		/// </summary>
		public long Ticks
		{
			get
			{
				return TimeSpan.TicksPerHour * this.hours + TimeSpan.TicksPerMinute * this.minutes +
					TimeSpan.TicksPerSecond * this.seconds;
			}
		}
		#endregion

		#region Time

		/// <summary>
		/// Gets { DateTime (n.Year, n.Month, n.Day, this.hours, this.minutes, this.seconds) }
		/// </summary>
		public DateTime Time
		{
			get
			{
				DateTime n = DateTime.Now;
				return new DateTime (n.Year, n.Month, n.Day, this.hours, this.minutes, this.seconds);
			}
		}
		#endregion

		#region NextRun

		/// <summary>
		/// Gets datetime for the next run of the period
		/// </summary>
		public DateTime NextRun
		{
			get
			{
				if (!this.IsEmpty)
				{
					DateTime n = DateTime.Now;

					if (this.start <= n)
					{
						DateTime d;

						if (this.use_days)
						{
							d = new DateTime (this.start.Year, this.start.Month, this.start.Day);
							long ticks = this.Ticks;

							while (d.AddTicks (ticks) <= n)
								d = d.AddDays (this.days);

							d = d.AddTicks (ticks);
						}
						else
						{
							d = this.start;
							long ticks = this.Ticks;
							long diff_ticks = (n.Subtract (d)).Ticks;
							d = d.AddTicks (((long) (diff_ticks / ticks) + 1) * ticks);
						}

						return d;
					}
				}

				return this.start;
			}
		}
		#endregion

		#endregion

		#region Constructors, destructor
		public DateTimePeriod ()
		{
			this.use_days = false;
			this.start = DateTime.Now;
		}

		public DateTimePeriod (int days, bool use_days, int hours, int minutes, int seconds, DateTime start)
		{
			this.use_days = use_days;
			this.days = days;
			this.hours = hours;
			this.minutes = minutes;
			this.seconds = seconds;
			this.start = start;

			this.Normalize ();
		}

		public DateTimePeriod (int days, bool use_days, DateTime time, DateTime start)
		{
			this.use_days = use_days;
			this.days = days;
			this.hours = time.Hour;
			this.minutes = time.Minute;
			this.seconds = time.Second;
			this.start = start;

			this.Normalize ();
		}

		public DateTimePeriod (string serialized_str)
		{
			this.Deserialize (serialized_str);
		}
		#endregion

		public override string ToString ()
		{
			string str = "";

			if (this.IsEmpty)
				str += " ";
			else
			{
				str += " ";

				bool need_comma = false;
				if (this.use_days)
				{
					str += this.days + ".  " + this.Time.ToString (LmUtils.ConvertUtilities.LmTimeFormat);
					need_comma = true;
				}
				else
				{
					if (this.hours != 0)
					{
						if (need_comma)
							str += ",";

						str += this.hours + ".";
						need_comma = true;
					}
					if (this.minutes != 0)
					{
						if (need_comma)
							str += ",";

						str += this.minutes + ".";
						need_comma = true;
					}
					if (this.seconds != 0)
					{
						if (need_comma)
							str += ",";

						str += this.seconds + ".";
						need_comma = true;
					}
				}

				str += ",   " + this.start.ToString (LmUtils.ConvertUtilities.LmDateTimeLongFormat);
			}

			return str;
		}

		public void SetTimer (ref Timer timer)
		{
			if (!this.IsEmpty)
			{
				timer.Change (this.NextRun - DateTime.Now, this.Period);
			}
			else
			{
				timer.Change (-1, -1);
			}
		}

		public void Normalize ()
		{
			if (this.days < 0)
				this.days = 0;

			if (this.hours < 0)
				this.hours = 0;
			if (this.hours > 23)
				this.hours = 23;

			if (this.minutes < 0)
				this.minutes = 0;
			if (this.minutes > 59)
				this.minutes = 59;

			if (this.seconds < 0)
				this.seconds = 0;
			if (this.seconds > 59)
				this.seconds = 59;
		}

		#region Serialization
		/// <summary>
		/// [days:10],[use_days:1],[hours:2],[minutes:2],[seconds:2],[start:19,MsSqlDateTimeFormat],[next_run:19,MsSqlDateTimeFormat - can be "NULL"]
		/// MsSqlDateTimeFormat: yyyy-MM-dd hh:mm:ss
		/// </summary>
		/// <returns>Serialized DateTimePeriod object</returns>
		public string Serialize ()
		{
			this.Normalize ();
			
			return String.Format ("{0,-10},{1,1},{2,-2},{3,-2},{4,-2},{5,-19},{6,-19}",
				this.days, this.use_days ? 1 : 0, this.hours, this.minutes, this.seconds,
				this.start.ToString (LmUtils.ConvertUtilities.MsSqlDateTimeFormat),
				!this.IsEmpty ? this.NextRun.ToString (LmUtils.ConvertUtilities.MsSqlDateTimeFormat) : "NULL");
		}

		/// <summary>
		/// [days:10],[use_days:1],[hours:2],[minutes:2],[seconds:2],[start:19,MsSqlDateTimeFormat],[next_run:19,MsSqlDateTimeFormat - can be "NULL"]
		/// MsSqlDateTimeFormat: yyyy-MM-dd hh:mm:ss
		/// </summary>
		/// <param name="str">Serialized DateTimePeriod object</param>
		public void Deserialize (string str)
		{
			string[] parts = str.Split (',');

			try
			{
				this.days = Convert.ToInt32 (parts[0]);
			}
			catch {}

			try
			{
				this.use_days = (Convert.ToInt32 (parts[1]) == 1);
			}
			catch {}

			try
			{
				this.hours = Convert.ToInt32 (parts[2]);
			}
			catch {}

			try
			{
				this.minutes = Convert.ToInt32 (parts[3]);
			}
			catch {}

			try
			{
				this.seconds = Convert.ToInt32 (parts[4]);
			}
			catch {}

			try
			{
				this.start = LmUtils.ConvertUtilities.MsSqlDatetimeToDateTime (parts[5]);
			}
			catch {}

			this.Normalize ();
		}
		#endregion
	}
}
