﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Text.RegularExpressions;

#endregion

namespace LmUtils
{
	public class CommandLineArguments
	{
		public Hashtable args;

		#region Constructors, destructor...
		public CommandLineArguments () : this (Environment.CommandLine)
		{
		}
		public CommandLineArguments (string cmd_line)
		{
			this.args = new Hashtable ();

			cmd_line = Regex.Replace (cmd_line, @"[\s]*/(?<key>[^=\s]+)[=\s]*(?<value>[\S]*)[\s]*", @" /${key}=${value}");
			ArrayList arguments = new ArrayList (cmd_line.Split (new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries));
			arguments.RemoveAt (0);

			foreach (string arg in arguments)
			{
				string[] arg_parts = arg.Split ('=');
				string key = arg_parts[0].Trim ();
				string val = arg_parts.Length > 1 ? arg_parts[1].Trim ('"').Trim () : null;

				if (!this.args.ContainsKey (key))
					this.args.Add (key, val);
				else
					this.args[key] = val;
			}
		} 
		#endregion

		#region Accessors
		/// <summary>
		/// Get
		/// </summary>
		/// <param name="name">argument name</param>
		/// <returns>argument or null if not present</returns>
		public string this[string name]
		{
			get
			{
				if (!this.args.ContainsKey (name))
					return null;
				else
					return (string)this.args[name];
			}
		}
		#endregion
	}
}
