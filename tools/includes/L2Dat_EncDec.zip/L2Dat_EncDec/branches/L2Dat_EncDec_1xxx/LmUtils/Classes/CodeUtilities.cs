#region Using directives

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

#endregion

namespace LmUtils
{
	public static class CodeUtilities
	{
		/// <summary>
		/// Makes name/value list from enum
		/// </summary>
		/// <param name="enum_type">enum type</param>
		/// <returns>name/value dictionary</returns>
		public static Dictionary<string,object> Enum_GetNameValueList (Type enum_type)
		{
			Dictionary<string, object> res = new Dictionary<string, object> ();

			string[] names = Enum.GetNames (enum_type);
			Array values = Enum.GetValues (enum_type);
			Type type = Enum.GetUnderlyingType (enum_type);

			for (int k = 0; k < names.Length; k++)
			{
				res.Add (names[k], Convert.ChangeType (values.GetValue (k), type));
			}

			return res;
		}
	}
} 