﻿using System;
using System.Collections.Generic;
using System.Text;
using L2ItemEncDec.Parsers;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Drawing;

namespace L2ItemEncDec
{
	#region class ItemInfo

	public class ItemInfo
	{
		#region Accessors

		#region Name
		protected string name;

		/// <summary>
		/// Gets or sets name of the item
		/// </summary>
		[Browsable (false)]
		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = value;
			}
		}
		#endregion

		#region Amount
		protected int amount;

		/// <summary>
		/// Gets or sets amount of item
		/// </summary>
		[Browsable (false)]
		public int Amount
		{
			get
			{
				return this.amount;
			}
			set
			{
				this.amount = value;
			}
		}
		#endregion

		#region Amount2
		protected int amount2;

		/// <summary>
		/// Gets or sets amount2 of item
		/// </summary>
		[Browsable (false)]
		public int Amount2
		{
			get
			{
				return this.amount2;
			}
			set
			{
				this.amount2 = value;
			}
		}
		#endregion

		#region Amount3
		protected int amount3;

		/// <summary>
		/// Gets or sets amount3 of item
		/// </summary>
		[Browsable (false)]
		public int Amount3
		{
			get
			{
				return this.amount3;
			}
			set
			{
				this.amount3 = value;
			}
		}
		#endregion

		#region Amount4
		protected int amount4;

		/// <summary>
		/// Gets or sets amount4 of item
		/// </summary>
		[Browsable (false)]
		public int Amount4
		{
			get
			{
				return this.amount4;
			}
			set
			{
				this.amount4 = value;
			}
		}
		#endregion

		#region SortIndex
		protected int sort_index = -1;

		/// <summary>
		/// Gets or sets index used to determine order
		/// </summary>
		[Browsable (false)]
		public int SortIndex
		{
			get
			{
				return this.sort_index;
			}
			set
			{
				this.sort_index = value;
			}
		}
		#endregion

		#region Recipe
		protected RecipeC.RecipeInfo recipe = null;

		/// <summary>
		/// Gets or sets recipe for crafting item
		/// </summary>
		[Browsable (false)]
		public RecipeC.RecipeInfo Recipe
		{
			get
			{
				return this.recipe;
			}
			set
			{
				this.recipe = value;
			}
		}
		#endregion

		#endregion

		#region Constructors, destructor...

		public ItemInfo (string name, int amount)
		{
			this.Name = name;
			this.Amount = amount;
			this.Amount2 = amount;
			this.Amount3 = amount;
			this.Amount4 = amount;
		}

		public ItemInfo (string name, int amount, int amount2)
			: this (name, amount)
		{
			this.Amount2 = amount2;
			this.Amount3 = amount2;
		}

		public ItemInfo (string name, int amount, int amount2, int amount3)
			: this (name, amount, amount2)
		{
			this.Amount3 = amount3;
		}

		public ItemInfo ()
			: this (null, 1)
		{
		}

		#endregion

		#region Format text

		public string FormatText2 ()
		{
			return String.Format ("{0} ({1})", this.Name, this.amount);
		}

		#endregion

	}

	#endregion

	#region class MobInfo

	public class MobInfo
	{
		public int id;
		public int level;
		public int hp;
		public bool aggro;
		public string name;
		public string title;

		public MobInfo (int id, string name, string title, int level, int hp, bool aggro)
		{
			this.id = id;
			this.name = name;
			this.title = title;
			this.level = level;
			this.hp = hp;
			this.aggro = aggro;
		}
	}

	#endregion

	public class CharacterInfo
	{
		public string name;
		public Collection<ItemInfo> items;

		#region Constructors, destructor and other base methods ...

		public CharacterInfo (string name)
		{
			this.name = name;
			this.items = new Collection<ItemInfo> ();
		}

		public override string ToString ()
		{
			return this.name;
		}

		#endregion
	}

	public static class ProgramData
	{
		public static Dictionary<int, MobInfo> mobs_by_id = null;
		public static Dictionary<string, MobInfo> mobs_by_name = null;
		public static Dictionary<int, string> items_by_id = null;
		public static Collection<RecipeC.RecipeInfo> recipes = null;
		public static Dictionary<int, RecipeC.RecipeInfo> recipes_by_id = null;
		public static Dictionary<string, Collection<RecipeC.RecipeInfo>> item_recipes_by_item_names = null;

		public static List<string> items = null;
		public static List<string> used_items = null;
		public static List<int> used_items_id = null;
		public static List<string> craftable_items = null;

		public static void Init ()
		{
			// load mobs data
			ProgramData.mobs_by_id = new Dictionary<int, MobInfo> ();
			ProgramData.mobs_by_name = new Dictionary<string,MobInfo> ();
            LmUtils.Xml xml = new LmUtils.Xml(Path.Combine(LmUtils.GlobalUtilities.GetStartDirectory(false), "mobs.xml"));

			int id = -1;
			string name = "";

			try
			{
				foreach (XmlElement node in xml.GetNodes ("mob[]"))
				{
					id = Convert.ToInt32 (node["id"].InnerText);
					name = node["name"].InnerText;

					string title = node["title"].InnerText;

					int level = 0;
					Int32.TryParse (node["level"].InnerText, out level);

					int hp = 0;
					Int32.TryParse (node["hp"].InnerText, out hp);

					bool aggro = false;
					if (node["aggro"] != null)
					{
						int value;
						if (Int32.TryParse (node["aggro"].InnerText, out value))
							aggro = (value == 1);
					}

					MobInfo info = new MobInfo (id, name, title, level, hp, aggro);
					ProgramData.mobs_by_id.Add (id, info);

					if (!ProgramData.mobs_by_name.ContainsKey (name))
						ProgramData.mobs_by_name.Add (name, info);
					else
						ProgramData.mobs_by_name[name] = info;
				}
			}
			catch (Exception ex)
			{
				Program.log.Add (new ApplicationException (
					string.Format ("Error loading mobs.xml (near the name='{0}' and id={1})\n\n", name, id), ex), true);
			}

			// load items
			ProgramData.items = new List<string> ();

			ProgramData.items_by_id = new Dictionary<int, string> ();
			{
				BinaryReader f = L2EncDec.Decrypt (Program.config.LineAge_itemnamee, Encoding.Default);
				if (f == null)
					return;

				List<ItemNameE.ItemNameInfo> items = ItemNameE.Parse (f);
				f.Close ();

				foreach (ItemNameE.ItemNameInfo item in items)
				{
					string item_name = item.ToString ();
					ProgramData.items_by_id.Add (item.id, item_name);
					ProgramData.items.Add (item_name);
				}
			}

			// load recipes
			ProgramData.used_items = new List<string> ();
			ProgramData.used_items_id = new List<int> ();
			ProgramData.craftable_items = new List<string> ();

			ProgramData.recipes_by_id = new Dictionary<int, RecipeC.RecipeInfo> ();
			ProgramData.item_recipes_by_item_names = new Dictionary<string, Collection<RecipeC.RecipeInfo>> ();
			{
				BinaryReader f = L2EncDec.Decrypt (Program.config.LineAge_recipec_dat, Encoding.Default);
				if (f == null)
					return;

				ProgramData.recipes = RecipeC.Parse (f, null, null);
				f.Close ();

				foreach (RecipeC.RecipeInfo rec in ProgramData.recipes)
				{
					ProgramData.recipes_by_id.Add (rec.id, rec);

					string item_name = ProgramData.items_by_id[rec.item_id];
					if (!ProgramData.craftable_items.Contains (item_name))
						ProgramData.craftable_items.Add (item_name);

					if (!ProgramData.item_recipes_by_item_names.ContainsKey (item_name))
						ProgramData.item_recipes_by_item_names.Add (item_name, new Collection<RecipeC.RecipeInfo> ());

					ProgramData.item_recipes_by_item_names[item_name].Add (rec);

					foreach (KeyValuePair<int, int> m in rec.materials)
					{
						string material_name = ProgramData.items_by_id[m.Key];

						if (!ProgramData.used_items.Contains (material_name))
							ProgramData.used_items.Add (material_name);

						if (!ProgramData.used_items_id.Contains (m.Key))
							ProgramData.used_items_id.Add (m.Key);
					}
				}

				ProgramData.used_items.Sort ();
				ProgramData.craftable_items.Sort ();
			}
		}
	}
}
