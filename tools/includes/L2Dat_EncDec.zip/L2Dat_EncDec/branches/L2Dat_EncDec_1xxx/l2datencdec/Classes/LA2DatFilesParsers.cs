﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.ComponentModel;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Collections;
using System.Collections.Specialized;

namespace L2DatEncDec.Parsers
{
	#region Helpers

	public class L2EncDec
	{
		public static BinaryReader Decrypt (string fname, Encoding enc)
		{
			Process process_decoder = new Process ();
			string decoder_output = "";

			string fname_encoded = Path.Combine (Program.config.LineAgeDirectory, fname);
			string fname_decoded = Path.GetTempFileName ();

			try
			{
                process_decoder.StartInfo.FileName = Path.Combine(LmUtils.GlobalUtilities.GetStartDirectory(false), @"l2encdec\l2encdec.exe");
				process_decoder.StartInfo.UseShellExecute = false;
				process_decoder.StartInfo.CreateNoWindow = true;
				process_decoder.StartInfo.RedirectStandardOutput = true;
				process_decoder.StartInfo.Arguments = String.Format ("-s \"{0}\" \"{1}\"", fname_encoded, fname_decoded);
				process_decoder.Start ();
				process_decoder.WaitForExit ();

				if (process_decoder.ExitCode < 0)
				{
					// lets try with -g switch
					process_decoder.StartInfo.Arguments = String.Format ("-g \"{0}\" \"{1}\"", fname_encoded, fname_decoded);
					process_decoder.Start ();
					process_decoder.WaitForExit ();

					if (process_decoder.ExitCode < 0)
					{
						// guess this file is not encrypted
						fname_decoded = fname_encoded;
					}
				}

				try
				{
					decoder_output = process_decoder.StandardOutput.ReadToEnd ();
				}
				catch
				{
				}

				return new BinaryReader (File.OpenRead (fname_decoded), enc);
			}
			catch (Exception ex)
			{
				throw new ApplicationException (
					String.Format ("Error decoding '{0}':\n\n{1}", fname_encoded, decoder_output), ex);
			}
			finally
			{
				process_decoder.Dispose ();
			}
		}

		public static void Encrypt (string fname)
		{
			if (String.IsNullOrEmpty (Program.config.LineAge_EncryptParameters))
				return;

			Process process_encoder = new Process ();
			string encoder_output = "";

			string fname_encoded = Path.Combine (Program.config.LineAgeDirectory, fname);
            string fname_decoded = Path.ChangeExtension(fname_encoded, "tmp");

			try
			{
				File.Delete (fname_decoded);
				File.Move (fname_encoded, fname_decoded);

                process_encoder.StartInfo.FileName = Path.Combine(LmUtils.GlobalUtilities.GetStartDirectory(false), @"l2encdec\l2encdec.exe");
				process_encoder.StartInfo.UseShellExecute = false;
				process_encoder.StartInfo.CreateNoWindow = true;
				process_encoder.StartInfo.RedirectStandardOutput = true;
				process_encoder.StartInfo.Arguments = String.Format ("{0} \"{1}\" \"{2}\"", Program.config.LineAge_EncryptParameters, fname_decoded, fname_encoded);
				process_encoder.Start ();
				process_encoder.WaitForExit ();

				try
				{
					encoder_output = process_encoder.StandardOutput.ReadToEnd ();
				}
				catch
				{
				}

				File.Delete (fname_decoded);
			}
			catch (Exception ex)
			{
				try
				{
					File.Move (fname_decoded, fname_encoded);
				}
				catch
				{
				}

				throw new ApplicationException (
					String.Format ("Error encoding '{0}':\n\n{1}", fname_decoded, encoder_output), ex);
			}
			finally
			{
				process_encoder.Dispose ();
			}
		}
	}

	class LA2DatFileParserHelpers
	{
        public static int ReadByteCount(BinaryReader f)
        {
            byte tmp = f.ReadByte();
            int len = tmp & 0x3F;
            if ((tmp & 0x40) > 0)
            {
                tmp = f.ReadByte();
                len += tmp << 6;
            }
            return len;
        }

        public static string ReadString(BinaryReader f)
		{
			int len = f.ReadByte ();
			if (len == 0)
				return "";
            if (len >= 192)
                f.BaseStream.Seek(1, SeekOrigin.Current);
            long start_pos = f.BaseStream.Position;
			long end_pos = start_pos;

			Encoding enc = Encoding.Default;
			byte one_ch_len = 1;

			if (len > 128)
			{
				// unicode string
				enc = Encoding.Unicode;
				one_ch_len = 2;

				while (true)
				{
					short ch = f.ReadInt16 ();
					if (ch == 0)
					{
						end_pos = f.BaseStream.Position;
						break;
					}
				}
			}
			else
			{
				if (char.IsControl ((char) f.PeekChar ()))
				{
					f.BaseStream.Seek (1, SeekOrigin.Current);
					start_pos = f.BaseStream.Position;
				}

				// ansi string
				while (true)
				{
					byte ch = f.ReadByte ();
					if (ch == 0)
					{
						end_pos = f.BaseStream.Position;
						break;
					}
				}
			}

			long real_len = end_pos - start_pos - one_ch_len;

			f.BaseStream.Seek (start_pos, SeekOrigin.Begin);

			byte[] buf = f.ReadBytes ((int) real_len);
			string res = enc.GetString (buf);

			f.BaseStream.Seek (one_ch_len, SeekOrigin.Current);

			return res;
		}

		public static string ReadStringSimple_UnicodeInt32Length (BinaryReader f)
		{
			int len = f.ReadInt32 ();
			if (len == 0)
				return "";

			byte[] buf = new byte[len];
			f.Read (buf, 0, (int) len);

			return Encoding.Unicode.GetString (buf);
		}

        public static void WriteByteCount(BinaryWriter f, int len)
        {
            if (len > 0x3F)
            {
                int LByte = len & 0x3F;
                int HByte = len >> 6;
                f.Write((byte)(LByte | 0x40));
                f.Write((byte)HByte);
            }
            else
            {
                f.Write((byte)len);
            }
        }

        public static void WriteString(BinaryWriter f, string str)
		{
			if (!String.IsNullOrEmpty (str))
			{
				bool is_unicode = false;
				for (int k = 0; k < str.Length; k++)
				{
					int code = (int) str[k];
					if (code > 255 && code != 1081)
					{
						is_unicode = true;
						break;
					}
				}

				int len = str.Length + 1;
				if (len >= 64)
				{
					int len_part2 = len / 64;
					int len_part1 = len - ((len_part2 - 1) * 64);

					// set highest bit cause to indicate it is Unicode
					if (is_unicode)
						len_part1 += 128;

					f.Write ((byte) len_part1);
					f.Write ((byte) len_part2);
				}
				else
				{
					// set highest bit cause to indicate it is Unicode
					if (is_unicode)
						len += 128;

					f.Write ((byte) len);
				}

				if (is_unicode)
				{
					f.Write (Encoding.Unicode.GetBytes (str));
					f.Write ((byte) 0x00);
				}
				else
				{
					f.Write (Encoding.Default.GetBytes (str));
				}
			}

			f.Write ((byte) 0x00);
		}

		public static void WriteStringSimple_UnicodeInt32Length (BinaryWriter f, string str)
		{

            f.Write((UInt32)(str.Length*2));

			if (str.Length > 0)
				f.Write (Encoding.Unicode.GetBytes (str));
		}

        public static void Debug_ByteToChar(BinaryReader f, int cnt)
        {
            for (int k = 0; k < cnt; k++)
            {
                byte temp = f.ReadByte();
                Console.Out.WriteLine(String.Format("0x{0:X2}", temp));
            }
        }
    }

	#endregion

    #region ActionName

    public class ActionName
    {
        public delegate void OnWorkProgressChangedDelegate(int percent);
        public static bool FireOnChangevents = true;

        public class ActionNameInfo
        {
            public int tags;
            public int id;
            public int type;
            public int category;
            public int cat2_cnt;
            public string cat2_ids;
            public string cmd;
            public string icon;
            public string name;
            public string desc;

            private object tag;

            public delegate void OnEventDelegate(ActionNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<ActionNameInfo> Parse(BinaryReader f)
        {
            List<ActionNameInfo> res = new List<ActionNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            int max_k = total_records;
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    ActionNameInfo info = new ActionNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT tag;
	                    UINT id;
	                    INT  type;
	                    UINT category;
	                    CNTR cat2_cnt;
	                    INT  c[cat2_cnt];
	                    ASCF cmd;
	                    ASCF icon;
	                    ASCF name;
	                    UNICODE desc;
                    }
                    */
                    info.tags = f.ReadInt32();
                    info.id = f.ReadInt32();
                    info.type = f.ReadInt32();
                    info.category = f.ReadInt32();
                    info.cat2_cnt = LA2DatFileParserHelpers.ReadByteCount(f);
                    info.cat2_ids = "";
                    for (int i = 0; i < info.cat2_cnt; i++)
                    {
                        info.cat2_ids += f.ReadInt32().ToString();
                        if (i < info.cat2_cnt - 1)
                            info.cat2_ids += ",";
                    }
                    info.cmd = LA2DatFileParserHelpers.ReadString(f);
                    info.icon = LA2DatFileParserHelpers.ReadString(f);
                    info.name = LA2DatFileParserHelpers.ReadString(f);
                    info.desc = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing action names file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<ActionNameInfo> infos)
        {
            f.Write(infos.Count);

            int max_k = infos.Count;
            foreach (ActionNameInfo info in infos)
            {
                f.Write(info.tags);
                f.Write(info.id);
                f.Write(info.type);
                f.Write(info.category);
                string[] TmpStr = info.cat2_ids.Split(new char[] { ',' });
                info.cat2_cnt = TmpStr.Length;
                LA2DatFileParserHelpers.WriteByteCount(f, info.cat2_cnt);
                for (int i = 0; i < info.cat2_cnt; i++)
                {
                    f.Write((Int32)Convert.ToInt32(TmpStr[i]));
                }
                LA2DatFileParserHelpers.WriteString(f, info.cmd);
                LA2DatFileParserHelpers.WriteString(f, info.icon);
                LA2DatFileParserHelpers.WriteString(f, info.name);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.desc);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region CastleName

    public class CastleName
    {
        public delegate void OnWorkProgressChangedDelegate(int percent);
        public static bool FireOnChangevents = true;

        public class CastleNameInfo
        {
            public int nbr;
            public int tags;
            public int id;
            public string castle_name;
            public string location;
            public string desc;

            private object tag;

            public delegate void OnEventDelegate(CastleNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<CastleNameInfo> Parse(BinaryReader f)
        {
            List<CastleNameInfo> res = new List<CastleNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            int max_k = total_records;
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    CastleNameInfo info = new CastleNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
                        UINT nbr;
                        UINT tag;
                        UINT id;
                        ASCF castle_name;
                        ASCF location;
                        ASCF desc;
                    }
                    */
                    info.nbr = f.ReadInt32();
                    info.tags = f.ReadInt32();
                    info.id = f.ReadInt32();
                    info.castle_name = LA2DatFileParserHelpers.ReadString(f);
                    info.location = LA2DatFileParserHelpers.ReadString(f);
                    info.desc = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing castle names file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<CastleNameInfo> infos)
        {
            f.Write(infos.Count);

            int max_k = infos.Count;
            foreach (CastleNameInfo info in infos)
            {
                f.Write(info.nbr);
                f.Write(info.tags);
                f.Write(info.id);
                LA2DatFileParserHelpers.WriteString(f, info.castle_name);
                LA2DatFileParserHelpers.WriteString(f, info.location);
                LA2DatFileParserHelpers.WriteString(f, info.desc);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region CommandName

    public class CommandName
    {
        public delegate void OnWorkProgressChangedDelegate(int percent);
        public static bool FireOnChangevents = true;

        public class CommandNameInfo
        {
            public int nbr;
            public int id;
            public string name;

            private object tag;

            public delegate void OnEventDelegate(CommandNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<CommandNameInfo> Parse(BinaryReader f)
        {
            List<CommandNameInfo> res = new List<CommandNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            int max_k = total_records;
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    CommandNameInfo info = new CommandNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT nbr;
	                    UINT id;
	                    ASCF name;
                    }
                    */
                    info.nbr = f.ReadInt32();
                    info.id = f.ReadInt32();
                    info.name = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing castle names file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<CommandNameInfo> infos)
        {
            f.Write(infos.Count);

            int max_k = infos.Count;
            foreach (CommandNameInfo info in infos)
            {
                f.Write(info.nbr);
                f.Write(info.id);
                LA2DatFileParserHelpers.WriteString(f, info.name);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region GameTip

    public class GameTip
    {
        public class GameTipInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
            public int tmp1;
            public int tmp2;
            public int enable;
            public string tip;

            private object tag;

            public delegate void OnEventDelegate(GameTipInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<GameTipInfo> Parse(BinaryReader f)
        {
            List<GameTipInfo> res = new List<GameTipInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    GameTipInfo info = new GameTipInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT id;
	                    UINT int1;
	                    UINT int2;
	                    UINT enable_?;
	                    ASCF tip;
                    }
                    */
                    info.id = f.ReadInt32();
                    info.tmp1 = f.ReadInt32();
                    info.tmp2 = f.ReadInt32();
                    info.enable = f.ReadInt32();
                    info.tip = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing GameTip string file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<GameTipInfo> infos)
        {
            f.Write(infos.Count);

            foreach (GameTipInfo info in infos)
            {
                f.Write(info.id);
                LA2DatFileParserHelpers.WriteString(f, info.tip);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region HuntingZone

    public class HuntingZone
    {
        public class HuntingZoneInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
            public int hunting_type;
            public int level;
            public float loc_x;
            public float loc_y;
            public float loc_z;
            public string unk2;
            public int affiliated_area_id;
            public string name;

            private object tag;

            public delegate void OnEventDelegate(HuntingZoneInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<HuntingZoneInfo> Parse(BinaryReader f)
        {
            List<HuntingZoneInfo> res = new List<HuntingZoneInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    HuntingZoneInfo info = new HuntingZoneInfo();

                    /*
                    Info from l2asm-disasm
                    { 
                       UINT id; 
                       UINT hunting_type; 
                       UINT level; 
                       UINT unk_1; 
                       FLOAT loc_x; 
                       FLOAT loc_y; 
                       FLOAT loc_z; 
                       CHEX unk_2[1]; 
                       UINT affiliated_area_id; 
                       ASCF name; 
                    }
                    */
                    info.id = f.ReadInt32();
                    info.hunting_type = f.ReadInt32();
                    info.level = f.ReadInt32();
                    f.ReadInt32(); // unk1:00 00 00 00
                    info.loc_x = f.ReadSingle();
                    info.loc_y = f.ReadSingle();
                    info.loc_z = f.ReadSingle();
                    info.unk2 = LA2DatFileParserHelpers.ReadString(f); // unk2
                    info.affiliated_area_id = f.ReadInt32();
                    info.name = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing HuntingZone file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<HuntingZoneInfo> infos)
        {
            f.Write(infos.Count);

            foreach (HuntingZoneInfo info in infos)
            {
                f.Write(info.id);
                f.Write(info.hunting_type);
                f.Write(info.level);
                f.Write((Int32)0x00);
                f.Write(info.loc_x);
                f.Write(info.loc_y);
                f.Write(info.loc_z);
                LA2DatFileParserHelpers.WriteString(f, info.unk2);
                f.Write(info.affiliated_area_id);
                LA2DatFileParserHelpers.WriteString(f, info.name);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region ItemName

	public class ItemName
	{
		public class ItemNameInfo
		{
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
			public string name;
			public string additionalname;
			public string description;
			public int popup;
            public string set_ids;
            public string set_bonus_desc;
            public string set_extra_id;
            public string set_extra_desc;
            public int special_enchant_amount;
            public string special_enchant_desc;

            private object tag;

            public delegate void OnEventDelegate(ItemNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

		public static List<ItemNameInfo> Parse (BinaryReader f)
		{
            List<ItemNameInfo> res = new List<ItemNameInfo>();

			int total_records = f.ReadInt32 ();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
			{
				try
				{
					ItemNameInfo info = new ItemNameInfo ();

					/*
					Info from l2asm-disasm
					{ 
					   UINT id;
					   UNICODE name; 
					   UNICODE add_name; 
					   ASCF description; 
					   INT popup;
					   ASCF set_ids;
					   ASCF set_bonus_desc; 
					   ASCF set_extra_id; 
					   ASCF set_extra_desc; 
					   CHEX unk[2];
					   UINT special_enchant_amount; 
					   ASCF special_enchant_desc; 
					}
					*/
					info.id = f.ReadInt32 ();
                    info.name = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
					info.additionalname = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
					info.description = LA2DatFileParserHelpers.ReadString(f);
					info.popup = f.ReadInt32();
                    info.set_ids = LA2DatFileParserHelpers.ReadString(f);
					info.set_bonus_desc = LA2DatFileParserHelpers.ReadString(f);
					info.set_extra_id = LA2DatFileParserHelpers.ReadString(f);
					info.set_extra_desc = LA2DatFileParserHelpers.ReadString(f);
                    f.ReadBytes(2); // unk
                    info.special_enchant_amount = f.ReadInt32();
                    info.special_enchant_desc = LA2DatFileParserHelpers.ReadString(f);

					res.Add (info);
				}
				catch (Exception ex)
				{
					throw new ApplicationException (
						String.Format ("Error parsing item names file (record number: {0}, offset: 0x{1:X})",
						k, f.BaseStream.Position), ex);
				}
			}

			return res;
		}

        public static void Compile(BinaryWriter f, List<ItemNameInfo> infos)
		{
			f.Write (infos.Count);

			foreach (ItemNameInfo info in infos)
			{
				f.Write (info.id);
				LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.name);
				LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.additionalname);
				LA2DatFileParserHelpers.WriteString (f, info.description);
                f.Write(info.popup);
                LA2DatFileParserHelpers.WriteString(f, info.set_ids);
                LA2DatFileParserHelpers.WriteString(f, info.set_bonus_desc);
                LA2DatFileParserHelpers.WriteString(f, info.set_extra_id);
                LA2DatFileParserHelpers.WriteString(f, info.set_extra_desc);
                LA2DatFileParserHelpers.WriteString(f, "");
                LA2DatFileParserHelpers.WriteString(f, "");
                f.Write((UInt32)info.special_enchant_amount);
                LA2DatFileParserHelpers.WriteString(f, info.special_enchant_desc);
			}

			LA2DatFileParserHelpers.WriteString (f, "SafePackage");
		}
	}

	#endregion

    #region NpcName

    public class NpcName
    {
        public delegate void OnWorkProgressChangedDelegate(int percent);
        public static bool FireOnChangevents = true;

        public class NpcNameInfo
        {
            public int id;
            public string name;
            public string title;
            public Color color;

            private object tag;

            public delegate void OnEventDelegate(NpcNameInfo info);
            public event OnEventDelegate OnChanged = null;

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }

            /// <summary>
            /// Gets or sets color (string HTML representation) of the mobs title
            /// </summary>
            [DisplayName("Title color"), Description("Color of the mobs title"), Category("Apperance"), Editor(typeof(Config.ColorEditor), typeof(System.Drawing.Design.UITypeEditor))]
            public string ColorStr
            {
                get
                {
                    return LmUtils.ConvertUtilities.ColorToHtmlColor(this.color);
                }
                set
                {
                    this.color = LmUtils.ConvertUtilities.HtmlColorToColor(value);

                    if (this.OnChanged != null && NpcName.FireOnChangevents)
                        this.OnChanged(this);
                }
            }
        }

        public static List<NpcNameInfo> Parse(BinaryReader f)
        {
            List<NpcNameInfo> res = new List<NpcNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            int max_k = total_records;
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    NpcNameInfo info = new NpcNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT id;
	                    ASCF name;
	                    ASCF description;
	                    CHEX rgb[3];
	                    CHAR reserved1;
                    }
                    */
                    info.id = f.ReadInt32();
                    info.name = LA2DatFileParserHelpers.ReadString(f);
                    info.title = LA2DatFileParserHelpers.ReadString(f);
                    info.color = Color.FromArgb(f.ReadInt32());

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing npc names file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<NpcNameInfo> infos)
        {
            f.Write(infos.Count);

            int max_k = infos.Count;
            foreach (NpcNameInfo info in infos)
            {
                f.Write(info.id);
                LA2DatFileParserHelpers.WriteString(f, info.name);
                LA2DatFileParserHelpers.WriteString(f, info.title);
                f.Write(info.color.ToArgb());
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region Obscene

    public class Obscene
    {
        public class ObsceneInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
            public string text;

            private object tag;

            public delegate void OnEventDelegate(ObsceneInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<ObsceneInfo> Parse(BinaryReader f)
        {
            List<ObsceneInfo> res = new List<ObsceneInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    ObsceneInfo info = new ObsceneInfo();

                    /*
                    Info from l2asm-disasm
                    { 
                       UINT id; 
                       ASCF text; 
                    }
                    */
                    info.id = f.ReadInt32();
                    info.text = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing obscene string file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<ObsceneInfo> infos)
        {
            f.Write(infos.Count);

            foreach (ObsceneInfo info in infos)
            {
                f.Write(info.id);
                LA2DatFileParserHelpers.WriteString(f, info.text);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region QuestName

    public class QuestName
    {
        public delegate void OnWorkProgressChangedDelegate(int percent);
        public static bool FireOnChangevents = true;

        public class QuestNameInfo
        {
            public int tags;
            public int quest_id;
            public int quest_prog;
            public string main_name;
            public string prog_name;
            public string description;
            public int tab1_cnt;
            public string tab1_str;
            public int tab2_cnt;
            public string tab2_str;
            public float quest_x;
            public float quest_y;
            public float quest_z;
            public int UNK_npc1;
            public int UNK_npc2;
            public int UNK_npc3;
            public string entity_name;
            public int UNK_1;
            public int UNK_2;
            public int UNK_3;
            public int UNK_4;
            public float entity_x;
            public float entity_y;
            public float entity_z;
            public string race_restricion;
            public string short_description;
            public int tab3_cnt;
            public string tab3_str;
            public int tab4_cnt;
            public string tab4_str;
            public int UNK_5;
            public int UNK_6;
            public int UNK_7;
            public int UNK_8;

            private object tag;

            public delegate void OnEventDelegate(QuestNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<QuestNameInfo> Parse(BinaryReader f)
        {
            List<QuestNameInfo> res = new List<QuestNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            int max_k = total_records;
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    QuestNameInfo info = new QuestNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT tag_?;
	                    UINT quest_id;
	                    UINT quest_prog;
	                    ASCF main_name;
	                    ASCF prog_name;
	                    ASCF description;
	                    CNTR cnt1;
	                    INT tab1[cnt1];
	                    CNTR cnt2;
	                    INT tab2[cnt2];
	                    FLOAT quest_x;
	                    FLOAT quest_y;
	                    FLOAT quest_z;
	                    UINT UNK_npc1_?;
	                    UINT UNK_npc2_?;
	                    UINT UNK_npc3_?;
	                    ASCF entity_name;
	                    UINT UNK_0;
	                    UINT UNK_1;
	                    UINT UNK_2;
	                    UINT UNK_3;
	                    FLOAT entity_x_?;
	                    FLOAT entity_y_?;
	                    FLOAT entity_z_?;
	                    ASCF race_restricion;
	                    ASCF short_description;
	                    CNTR cnt3;
	                    INT tab3[cnt3];
	                    CNTR cnt4;
	                    INT tab4[cnt4];
	                    UINT UNK_5;
	                    UINT UNK_6;
	                    UINT UNK_7;
	                    UINT UNK_8;
                    }
                    */
                    info.tags = f.ReadInt32();
                    info.quest_id = f.ReadInt32();
                    info.quest_prog = f.ReadInt32();
                    info.main_name = LA2DatFileParserHelpers.ReadString(f);
                    info.prog_name = LA2DatFileParserHelpers.ReadString(f);
                    info.description = LA2DatFileParserHelpers.ReadString(f);
                    info.tab1_cnt = LA2DatFileParserHelpers.ReadByteCount(f);
                    info.tab1_str = "";
                    for (int i = 0; i < info.tab1_cnt; i++)
                    {
                        info.tab1_str += f.ReadInt32().ToString();
                        if (i < info.tab1_cnt - 1)
                            info.tab1_str += ",";
                    }
                    info.tab2_cnt = LA2DatFileParserHelpers.ReadByteCount(f);
                    info.tab2_str = "";
                    for (int i = 0; i < info.tab2_cnt; i++)
                    {
                        info.tab2_str += f.ReadInt32().ToString();
                        if (i < info.tab2_cnt - 1)
                            info.tab2_str += ",";
                    }
                    info.quest_x = f.ReadSingle();
                    info.quest_y = f.ReadSingle();
                    info.quest_z = f.ReadSingle();
                    info.UNK_npc1 = f.ReadInt32();
                    info.UNK_npc2 = f.ReadInt32();
                    info.UNK_npc3 = f.ReadInt32();
                    info.entity_name = LA2DatFileParserHelpers.ReadString(f);
                    info.UNK_1 = f.ReadInt32();
                    info.UNK_2 = f.ReadInt32();
                    info.UNK_3 = f.ReadInt32();
                    info.UNK_4 = f.ReadInt32();
                    info.entity_x = f.ReadSingle();
                    info.entity_y = f.ReadSingle();
                    info.entity_z = f.ReadSingle();
                    info.race_restricion = LA2DatFileParserHelpers.ReadString(f);
                    info.short_description = LA2DatFileParserHelpers.ReadString(f);
                    info.tab3_cnt = LA2DatFileParserHelpers.ReadByteCount(f);
                    info.tab3_str = "";
                    for (int i = 0; i < info.tab3_cnt; i++)
                    {
                        info.tab3_str += f.ReadInt32().ToString();
                        if (i < info.tab3_cnt - 1)
                            info.tab3_str += ",";
                    }
                    info.tab4_cnt = LA2DatFileParserHelpers.ReadByteCount(f);
                    info.tab4_str = "";
                    for (int i = 0; i < info.tab4_cnt; i++)
                    {
                        info.tab4_str += f.ReadInt32().ToString();
                        if (i < info.tab4_cnt - 1)
                            info.tab4_str += ",";
                    }
                    info.UNK_5 = f.ReadInt32();
                    info.UNK_6 = f.ReadInt32();
                    info.UNK_7 = f.ReadInt32();
                    info.UNK_8 = f.ReadInt32();

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing action names file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<QuestNameInfo> infos)
        {
            f.Write(infos.Count);

            int max_k = infos.Count;
            foreach (QuestNameInfo info in infos)
            {
                //f.Write(info.id);
                //LA2DatFileParserHelpers.WriteString(f, info.name);
                //LA2DatFileParserHelpers.WriteString(f, info.title);
                //f.Write(info.color.ToArgb());
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region RaidData

    public class RaidData
    {
        public class RaidDataInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
            public int npc_id;
            public int npc_level;
            public int affiliated_area_id;
            public float loc_x;
            public float loc_y;
            public float loc_z;
            public string raid_desc;

            private object tag;

            public delegate void OnEventDelegate(RaidDataInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<RaidDataInfo> Parse(BinaryReader f)
        {
            List<RaidDataInfo> res = new List<RaidDataInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    RaidDataInfo info = new RaidDataInfo();

                    /*
                    Info from l2asm-disasm
                    { 
                       UINT id; 
                       UINT npc_id; 
                       UINT npc_level; 
                       UINT affiliated_area_id; 
                       FLOAT loc_x; 
                       FLOAT loc_y; 
                       FLOAT loc_z; 
                       ASCF raid_desc; 
                    }
                    */
                    info.id = f.ReadInt32();
                    info.npc_id = f.ReadInt32();
                    info.npc_level = f.ReadInt32();
                    info.affiliated_area_id = f.ReadInt32();
                    info.loc_x = f.ReadSingle();
                    info.loc_y = f.ReadSingle();
                    info.loc_z = f.ReadSingle();
                    info.raid_desc = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing raiddata file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<RaidDataInfo> infos)
        {
            f.Write(infos.Count);

            foreach (RaidDataInfo info in infos)
            {
                f.Write(info.id);
                f.Write(info.npc_id);
                f.Write(info.npc_level);
                f.Write(info.affiliated_area_id);
                f.Write(info.loc_x);
                f.Write(info.loc_y);
                f.Write(info.loc_z);
                LA2DatFileParserHelpers.WriteString(f, info.raid_desc);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region Recipe

    public class Recipe
    {
        public class RecipeInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public string name;
            public int id_mk;
            public int id_recipe;
            public int level;
            public int id_item;
            public int count;
            public int mp_cost;
            public int success_rate;
            public string materials;

            private object tag;

            public delegate void OnEventDelegate(RecipeInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<RecipeInfo> Parse(BinaryReader f)
        {
            List<RecipeInfo> res = new List<RecipeInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    RecipeInfo info = new RecipeInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    ASCF name;
	                    UINT id_mk;
	                    UINT id_recipe;
	                    UINT level;
	                    UINT id_item;
	                    UINT count;
	                    UINT mp_cost;
	                    UINT success_rate;
	                    MAT materials;
                    }
                    */
                    info.name = LA2DatFileParserHelpers.ReadString(f);
                    info.id_mk = f.ReadInt32();
                    info.id_recipe = f.ReadInt32();
                    info.level = f.ReadInt32();
                    info.id_item = f.ReadInt32();
                    info.count = f.ReadInt32();
                    info.mp_cost = f.ReadInt32();
                    info.success_rate = f.ReadInt32();
                    int MatCnt = f.ReadInt32();
                    info.materials = "";
                    for (int i = 0; i < MatCnt; i++)
                    {
                        info.materials += "[" + f.ReadInt32().ToString();
                        info.materials += "(" + f.ReadInt32().ToString() + ")]";
                        if (i < MatCnt - 1)
                            info.materials += ",";
                    }

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing Recipe string file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<RecipeInfo> infos)
        {
            f.Write(infos.Count);

            foreach (RecipeInfo info in infos)
            {
                //f.Write(info.id);
                //LA2DatFileParserHelpers.WriteString(f, info.text);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region ServerName

    public class ServerName
    {
        public class ServerNameInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int server_id;
            public int tags;
            public string server_name;
            public string server_desc;

            private object tag;

            public delegate void OnEventDelegate(ServerNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<ServerNameInfo> Parse(BinaryReader f)
        {
            List<ServerNameInfo> res = new List<ServerNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    ServerNameInfo info = new ServerNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT server_id;
	                    UINT tag_?;
	                    ASCF server_name;
	                    ASCF server_desc;
                    }
                    */
                    info.server_id = f.ReadInt32();
                    info.tags = f.ReadInt32(); // 01 00 00 00
                    info.server_name = LA2DatFileParserHelpers.ReadString(f);
                    info.server_desc = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing ServerName string file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<ServerNameInfo> infos)
        {
            f.Write(infos.Count);

            foreach (ServerNameInfo info in infos)
            {
                f.Write(info.server_id);
                f.Write(info.tags);
                LA2DatFileParserHelpers.WriteString(f, info.server_name);
                LA2DatFileParserHelpers.WriteString(f, info.server_desc);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region SkillName

    public class SkillName
    {
        public class SkillNameInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
            public int level;
            public string name;
            public string description;
            public string desc_add1;
            public string desc_add2;

            private object tag;

            public delegate void OnEventDelegate(SkillNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<SkillNameInfo> Parse(BinaryReader f)
        {
            List<SkillNameInfo> res = new List<SkillNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    SkillNameInfo info = new SkillNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
                        UINT id;
                        UINT level;
                        ASCF name;
                        ASCF description;
                        ASCF desc_add1;
                        ASCF desc_add2;
                    }
                    */
                    info.id = f.ReadInt32();
                    info.level = f.ReadInt32();
                    info.name = LA2DatFileParserHelpers.ReadString(f);
                    info.description = LA2DatFileParserHelpers.ReadString(f);
                    info.desc_add1 = LA2DatFileParserHelpers.ReadString(f);
                    info.desc_add2 = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing skill names file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<SkillNameInfo> infos)
        {
            f.Write(infos.Count);

            foreach (SkillNameInfo info in infos)
            {
                f.Write(info.id);
                f.Write(info.level);
                LA2DatFileParserHelpers.WriteString(f, info.name);
                LA2DatFileParserHelpers.WriteString(f, info.description);
                LA2DatFileParserHelpers.WriteString(f, info.desc_add1);
                LA2DatFileParserHelpers.WriteString(f, info.desc_add2);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region StaticObject

    public class StaticObject
    {
        public class StaticObjectInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
            public string name;

            private object tag;

            public delegate void OnEventDelegate(StaticObjectInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<StaticObjectInfo> Parse(BinaryReader f)
        {
            List<StaticObjectInfo> res = new List<StaticObjectInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    StaticObjectInfo info = new StaticObjectInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT id;
	                    UNICODE name;
                    }
                    */
                    info.id = f.ReadInt32();
                    info.name = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing StaticObject string file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<StaticObjectInfo> infos)
        {
            f.Write(infos.Count);

            foreach (StaticObjectInfo info in infos)
            {
                f.Write(info.id);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.name);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region SysString

    public class SysString
    {
        public class SysStringInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int id;
            public string name;

            private object tag;

            public delegate void OnEventDelegate(SysStringInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<SysStringInfo> Parse(BinaryReader f)
        {
            List<SysStringInfo> res = new List<SysStringInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    SysStringInfo info = new SysStringInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT id;
	                    ASCF name;
                    }
                    */
                    info.id = f.ReadInt32();
                    info.name = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing SysString string file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<SysStringInfo> infos)
        {
            f.Write(infos.Count);

            foreach (SysStringInfo info in infos)
            {
                f.Write(info.id);
                LA2DatFileParserHelpers.WriteString(f, info.name);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region SystemMsg

    public class SystemMsg
    {
        public delegate void OnWorkProgressChangedDelegate(int percent);
        public static bool FireOnChangevents = true;

        public class SystemMsgInfo
        {
            public int id;
            public uint group;
            public Color color;
            public string sound;
            public string msg;
            public string msg_ref;
            public string sub_msg;
            public string type;

            private object tag;

            public delegate void OnEventDelegate(SystemMsgInfo msg);
            public event OnEventDelegate OnChanged = null;

            /// <summary>
            /// Gets or sets object that contains data to associate with the message
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }

            /// <summary>
            /// Gets or sets color (string HTML representation) of the message
            /// </summary>
            [DisplayName("Color"), Description("Color of the message"), Category("Apperance"), Editor(typeof(Config.ColorEditor), typeof(System.Drawing.Design.UITypeEditor))]
            public string ColorStr
            {
                get
                {
                    return LmUtils.ConvertUtilities.ColorToHtmlColor(this.color);
                }
                set
                {
                    this.color = LmUtils.ConvertUtilities.HtmlColorToColor(value);

                    if (this.OnChanged != null && SystemMsg.FireOnChangevents)
                        this.OnChanged(this);
                }
            }
        }

        public static List<SystemMsgInfo> Parse(BinaryReader f)
        {
            List<SystemMsgInfo> res = new List<SystemMsgInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            int max_k = total_records;
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    SystemMsgInfo info = new SystemMsgInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT id;
	                    UINT UNK_0;
	                    ASCF message;
	                    UINT group;
	                    CHEX rgb[3];
	                    CHAR UNK_1;
	                    ASCF item_sound;
	                    ASCF sys_msg_ref;
                    }
                    */
                    info.id = f.ReadInt32();
                    f.ReadInt32(); // unk:01 00 00 00
                    info.msg = LA2DatFileParserHelpers.ReadString(f);
                    info.group = f.ReadUInt32();
                    if (Program.main_form.selectedChronicleIdx >= 4)
                    {
                        info.color = Color.FromArgb(f.ReadInt32());
                        info.sound = LA2DatFileParserHelpers.ReadString(f);
                        info.msg_ref = LA2DatFileParserHelpers.ReadString(f);
                        f.ReadInt32(); // unk:00 00 00 00
                        f.ReadInt32(); // unk:00 00 00 00
                        f.ReadInt32(); // unk:00 00 00 00
                        f.ReadInt32(); // unk:00 00 00 00
                        f.ReadInt32(); // unk:00 00 00 00
                        info.sub_msg = LA2DatFileParserHelpers.ReadString(f);
                        info.type = LA2DatFileParserHelpers.ReadString(f);
                    }
                    else
                    {
                        info.color = Color.FromArgb(f.ReadInt32());
                        //f.ReadInt32(); // unk:FF FF FF FF
                        info.sound = LA2DatFileParserHelpers.ReadString(f);
                        info.msg_ref = LA2DatFileParserHelpers.ReadString(f);
                    }

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing system messages file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<SystemMsgInfo> infos)
        {
            f.Write(infos.Count);

            int max_k = infos.Count;
            foreach (SystemMsgInfo info in infos)
            {
                f.Write(info.id);
                f.Write(1);	// unk:01 00 00 00
                LA2DatFileParserHelpers.WriteString(f, info.msg);
                f.Write(info.group);
                f.Write(info.color.ToArgb());
                //f.Write(-1); // unk:FF FF FF FF
                LA2DatFileParserHelpers.WriteString(f, info.sound);
                LA2DatFileParserHelpers.WriteString(f, info.msg_ref);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region Weapongrp

    public class Weapongrp
    {
        public class WeapongrpInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

			public int tags;
			public int id;
			public int drop_type;
			public int drop_anim_type;
			public int drop_radius;
			public int drop_height;
			public int UNK_0;
			public String drop_meshtex1;
			public String drop_meshtex2;
			public String icon1;
			public String icon2;
			public String icon3;
			public String icon4;
			public String icon5;
			public String icon6;
			public String icon7;
			public String icon8;
			public String icon9;
			public int  durability;
			public int weight;
			public int material;
			public int crystallizable;
			public int projectile;
			public int body_part;
			public int handness;
            public String UNK_1;
            public int cntm;
			public String mesh; // [cntm]
			public int cntt;
			public String text; // [cntt]
			public int item_sound_cnt;
			public String item_sound; // [item_sound_cnt]
			public String drop_sound;
			public String equip_sound;
			public String effect;
			public int random_damage;
			public int patt;
			public int matt;
			public int weapon_type;
			public int crystal_type;
			public int critical;
			public int hit_mod;
			public int avoid_mod;
			public int shield_pdef;
			public int shield_rate;
			public int speed;
			public int mp_consume;
			public int SS_count;
			public int SPS_count;
			public int curvature;
			public int UNK_2;
			public int is_hero;
			public int UNK_3;
			public String effA;
			public String effB;
            public String rangeA;
            public String rangeB;
            public float junk1A_1;
			public float junk1A_2;
			public float junk1A_3;
			public float junk1A_4;
            public float junk1A_5;
            public float junk1B_1;
            public float junk1B_2;
            public float junk1B_3;
            public float junk1B_4;
            public float junk1B_5;
            public float junk2A_1;
			public float junk2A_2;
			public float junk2A_3;
			public float junk2A_4;
            public float junk2A_5;
            public float junk2A_6;
            public float junk2B_1;
            public float junk2B_2;
            public float junk2B_3;
            public float junk2B_4;
            public float junk2B_5;
            public float junk2B_6;
            public int junk3_1;
			public int junk3_2;
			public int junk3_3;
			public int junk3_4;
			public String icons1;
			public String icons2;
			public String icons3;
			public String icons4;

            private object tag;

            public delegate void OnEventDelegate(WeapongrpInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<WeapongrpInfo> Parse(BinaryReader f)
        {
            List<WeapongrpInfo> res = new List<WeapongrpInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    WeapongrpInfo info = new WeapongrpInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT tag;
	                    UINT id;
	                    UINT drop_type;
	                    UINT drop_anim_type;
	                    UINT drop_radius;
	                    UINT drop_height;
	                    UINT UNK_0;
	                    UNICODE drop_meshtex[2];
		                    ORD=OFF;
	                    UNICODE icon[9];
		                    ORD=OFF;
	                    INT  durability;
	                    UINT weight;
	                    UINT material;
	                    UINT crystallizable;
	                    UINT projectile_?;
	                    UINT body_part;
	                    UINT handness;
	                    MTX mt_pair;
	                    UINT item_sound_cnt;
	                    UNICODE item_sound[item_sound_cnt];
		                    ORD=OFF;
	                    UNICODE drop_sound;
		                    ORD=OFF;
	                    UNICODE equip_sound;
		                    ORD=OFF;
	                    UNICODE effect;
		                    ORD=OFF;
	                    UINT random_damage;
	                    UINT patt;
	                    UINT matt;
	                    UINT weapon_type;
	                    UINT crystal_type;
	                    UINT critical;
	                    INT hit_mod;
	                    INT avoid_mod;
	                    UINT shield_pdef;
	                    UINT shield_rate;
	                    UINT speed;
	                    UINT mp_consume;
	                    UINT SS_count;
	                    UINT SPS_count;
	                    UINT curvature;
	                    UINT UNK_2;
	                    INT is_hero;
	                    UINT UNK_3;
	                    UNICODE effA;
	                    UNICODE effB;
		                    ENBBY = [(body_part,14),(handness,3)];
		                    ENBBY = [(body_part,14),(handness,7)];
	                    FLOAT junk1A[5];
	                    FLOAT junk1B[5];
		                    ENBBY = [(body_part,14),(handness,3)];
		                    ENBBY = [(body_part,14),(handness,7)];
	                    UNICODE rangeA;
	                    UNICODE rangeB;
		                    ENBBY = [(body_part,14),(handness,3)];
		                    ENBBY = [(body_part,14),(handness,7)];
	                    FLOAT junk2A[6];
	                    FLOAT junk2B[6];
		                    ENBBY = [(body_part,14),(handness,3)];
		                    ENBBY = [(body_part,14),(handness,7)];
	                    INT junk3[4];
	                    UNICODE icons[4];
                    }
                    */
                    info.tags = f.ReadInt32();
                    info.id = f.ReadInt32();
                    Console.Out.WriteLine("-------------------------------");
                    Console.Out.WriteLine("ID:" + info.id);
                    info.drop_type = f.ReadInt32();
                    info.drop_anim_type = f.ReadInt32();
                    info.drop_radius = f.ReadInt32();
                    info.drop_height = f.ReadInt32();
                    info.UNK_0 = f.ReadInt32();
                    info.drop_meshtex1 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.drop_meshtex2 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon1 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon2 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon3 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon4 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon5 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon6 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon7 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon8 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.icon9 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.durability = f.ReadInt32();
                    info.weight = f.ReadInt32();
                    info.material = f.ReadInt32();
                    info.crystallizable = f.ReadInt32();
                    info.projectile = f.ReadInt32();
                    if (Program.main_form.selectedChronicleIdx == 5)
                        info.UNK_1 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.body_part = f.ReadInt32();
                    info.handness = f.ReadInt32();
                    info.cntm = f.ReadInt32();
                    info.mesh = "";
                    for (int i = 0; i < info.cntm; i++)
                    {
                        info.mesh += LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                        if (i < info.cntm - 1)
                            info.mesh += ",";
                    }
                    info.cntt = f.ReadInt32();
                    info.text = "";
                    for (int i = 0; i < info.cntt; i++)
                    {
                        info.text += LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                        if (i < info.cntt - 1)
                            info.text += ",";
                    }
                    info.item_sound_cnt = f.ReadInt32();
                    info.item_sound = "";
                    for (int i = 0; i < info.item_sound_cnt; i++)
                    {
                        info.item_sound += LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                        if (i < info.item_sound_cnt - 1)
                            info.item_sound += ",";
                    }
                    info.drop_sound = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.equip_sound = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.effect = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.random_damage = f.ReadInt32();
                    info.patt = f.ReadInt32();
                    info.matt = f.ReadInt32();
                    info.weapon_type = f.ReadInt32();
                    info.crystal_type = f.ReadInt32();
                    info.critical = f.ReadInt32();
                    info.hit_mod = f.ReadInt32();
                    info.avoid_mod = f.ReadInt32();
                    info.shield_pdef = f.ReadInt32();
                    info.shield_rate = f.ReadInt32();
                    info.speed = f.ReadInt32();
                    info.mp_consume = f.ReadInt32();
                    info.SS_count = f.ReadInt32();
                    info.SPS_count = f.ReadInt32();
                    info.curvature = f.ReadInt32();
                    info.UNK_2 = f.ReadInt32();
                    info.is_hero = f.ReadInt32();
                    info.UNK_3 = f.ReadInt32();
                    info.effA = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                            (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                        info.effB = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.junk1A_1 = f.ReadSingle();
                    info.junk1A_2 = f.ReadSingle();
                    info.junk1A_3 = f.ReadSingle();
                    info.junk1A_4 = f.ReadSingle();
                    info.junk1A_5 = f.ReadSingle();
                    if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                            (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                    {
                        info.junk1B_1 = f.ReadSingle();
                        info.junk1B_2 = f.ReadSingle();
                        info.junk1B_3 = f.ReadSingle();
                        info.junk1B_4 = f.ReadSingle();
                        info.junk1B_5 = f.ReadSingle();
                    }
                    info.rangeA = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                            (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                        info.rangeB = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    info.junk2A_1 = f.ReadSingle();
                    info.junk2A_2 = f.ReadSingle();
                    info.junk2A_3 = f.ReadSingle();
                    info.junk2A_4 = f.ReadSingle();
                    info.junk2A_5 = f.ReadSingle();
                    info.junk2A_6 = f.ReadSingle();
                    if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                            (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                    {
                        info.junk2B_1 = f.ReadSingle();
                        info.junk2B_2 = f.ReadSingle();
                        info.junk2B_3 = f.ReadSingle();
                        info.junk2B_4 = f.ReadSingle();
                        info.junk2B_5 = f.ReadSingle();
                        info.junk2B_6 = f.ReadSingle();
                    }
                    if (Program.main_form.selectedChronicleIdx >= 4)
                    {
                        info.junk3_1 = f.ReadInt32();
                        info.junk3_2 = f.ReadInt32();
                        info.junk3_3 = f.ReadInt32();
                        info.junk3_4 = f.ReadInt32();
                        info.icons1 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                        info.icons2 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                        info.icons3 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                        info.icons4 = LA2DatFileParserHelpers.ReadStringSimple_UnicodeInt32Length(f);
                    }

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing weapongrp file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<WeapongrpInfo> infos)
        {
            f.Write(infos.Count);

            foreach (WeapongrpInfo info in infos)
            {
                f.Write(info.tags);
                f.Write(info.id);
                f.Write(info.drop_type);
                f.Write(info.drop_anim_type);
                f.Write(info.drop_radius);
                f.Write(info.drop_height);
                f.Write(info.UNK_0);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.drop_meshtex1);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.drop_meshtex2);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon1);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon2);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon3);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon4);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon5);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon6);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon7);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon8);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.icon9);
                f.Write(info.durability);
                f.Write(info.weight);
                f.Write(info.material);
                f.Write(info.crystallizable);
                f.Write(info.projectile);
                if (Program.main_form.selectedChronicleIdx == 5)
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.UNK_1);
                f.Write(info.body_part);
                f.Write(info.handness);
                string[] TmpStr = info.mesh.Split(new char[] { ',' });
                info.cntm = TmpStr.Length;
                f.Write(info.cntm);
                for (int i = 0; i < info.cntm; i++)
                {
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, TmpStr[i]);
                }
                string[] TmpStr2 = info.text.Split(new char[] { ',' });
                info.cntt = TmpStr2.Length;
                f.Write(info.cntt);
                for (int i = 0; i < info.cntt; i++)
                {
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, TmpStr2[i]);
                }
                string[] TmpStr3 = info.item_sound.Split(new char[] { ',' });
                info.item_sound_cnt = TmpStr3.Length;
                f.Write(info.item_sound_cnt);
                for (int i = 0; i < info.item_sound_cnt; i++)
                {
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, TmpStr3[i]);
                }
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.drop_sound);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.equip_sound);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.effect);
                f.Write(info.random_damage);
                f.Write(info.patt);
                f.Write(info.matt);
                f.Write(info.weapon_type);
                f.Write(info.crystal_type);
                f.Write(info.critical);
                f.Write(info.hit_mod);
                f.Write(info.avoid_mod);
                f.Write(info.shield_pdef);
                f.Write(info.shield_rate);
                f.Write(info.speed);
                f.Write(info.mp_consume);
                f.Write(info.SS_count);
                f.Write(info.SPS_count);
                f.Write(info.curvature);
                f.Write(info.UNK_2);
                f.Write(info.is_hero);
                f.Write(info.UNK_3);
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.effA);
                if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                        (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.effB);
                f.Write(info.junk1A_1);
                f.Write(info.junk1A_2);
                f.Write(info.junk1A_3);
                f.Write(info.junk1A_4);
                f.Write(info.junk1A_5);
                if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                        (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                {
                    f.Write(info.junk1B_1);
                    f.Write(info.junk1B_2);
                    f.Write(info.junk1B_3);
                    f.Write(info.junk1B_4);
                    f.Write(info.junk1B_5);
                }
                LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length (f, info.rangeA);
                if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                        (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.rangeB);
                f.Write(info.junk2A_1);
                f.Write(info.junk2A_2);
                f.Write(info.junk2A_3);
                f.Write(info.junk2A_4);
                f.Write(info.junk2A_5);
                f.Write(info.junk2A_6);
                if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                        (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                {
                    f.Write(info.junk2B_1);
                    f.Write(info.junk2B_2);
                    f.Write(info.junk2B_3);
                    f.Write(info.junk2B_4);
                    f.Write(info.junk2B_5);
                    f.Write(info.junk2B_6);
                }
                if (Program.main_form.selectedChronicleIdx >= 4)
                {
                    f.Write(info.junk3_1);
                    f.Write(info.junk3_2);
                    f.Write(info.junk3_3);
                    f.Write(info.junk3_4);
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.icons1);
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.icons2);
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.icons3);
                    LA2DatFileParserHelpers.WriteStringSimple_UnicodeInt32Length(f, info.icons4);
                }
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion

    #region ZoneName

    public class ZoneName
    {
        public class ZoneNameInfo
        {
            public delegate void OnWorkProgressChangedDelegate(int percent);

            public int nbr;
            public int zone_color_id;
            public int x_world_grid;
            public int y_world_grid;
            public float top_z;
            public float bottom_z;
            public string zone_name;
            public string map_name;

            private object tag;

            public delegate void OnEventDelegate(ZoneNameInfo info);

            /// <summary>
            /// Gets or sets object that contains data to associate with the npc
            /// </summary>
            [Browsable(false)]
            public object Tag
            {
                get
                {
                    return this.tag;
                }
                set
                {
                    this.tag = value;
                }
            }
        }

        public static List<ZoneNameInfo> Parse(BinaryReader f)
        {
            List<ZoneNameInfo> res = new List<ZoneNameInfo>();

            int total_records = f.ReadInt32();
            Console.Out.WriteLine("TOTAL:" + total_records);
            for (int k = 0; k < total_records; k++)
            {
                try
                {
                    ZoneNameInfo info = new ZoneNameInfo();

                    /*
                    Info from l2asm-disasm
                    { 
	                    UINT nbr;
	                    UINT zone_color_id;
	                    UINT x_world_grid;
	                    UINT y_world_grid;
	                    FLOAT top_z;
	                    FLOAT bottom_z;
	                    ASCF zone_name;
                    }
                    */
                    info.nbr = f.ReadInt32();
                    info.zone_color_id = f.ReadInt32();
                    info.x_world_grid = f.ReadInt32();
                    info.y_world_grid = f.ReadInt32();
                    info.top_z = f.ReadSingle();
                    info.bottom_z = f.ReadSingle();
                    info.zone_name = LA2DatFileParserHelpers.ReadString(f);
                    int tmpi1 = f.ReadInt32();
                    int tmpi2 = f.ReadInt32();
                    int tmpi3 = f.ReadInt32();
                    int tmpi4 = f.ReadInt32();
                    int tmpi5 = f.ReadInt32();
                    int tmpi6 = f.ReadInt32();
                    int tmpi7 = f.ReadInt32();
                    info.map_name = LA2DatFileParserHelpers.ReadString(f);

                    res.Add(info);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException(
                        String.Format("Error parsing ZoneName file (record number: {0}, offset: 0x{1:X})",
                        k, f.BaseStream.Position), ex);
                }
            }

            return res;
        }

        public static void Compile(BinaryWriter f, List<ZoneNameInfo> infos)
        {
            f.Write(infos.Count);

            foreach (ZoneNameInfo info in infos)
            {
                //f.Write(info.nbr);
                //f.Write(info.zone_color_id);
                //f.Write(info.x_world_grid);
                //f.Write(info.y_world_grid);
                //f.Write(info.top_z);
                //f.Write(info.bottom_z);
                //LA2DatFileParserHelpers.WriteString(f, info.zone_name);
            }

            LA2DatFileParserHelpers.WriteString(f, "SafePackage");
        }
    }

    #endregion
}
