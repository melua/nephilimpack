﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;
using LmUtils;

namespace L2DatEncDec
{
	static class Program
	{
		public static Config config;
        public static LmUtils.Log log;
		public static MainForm main_form;
        public static LmUtils.CommandLineArguments args;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main ()
		{
			Application.EnableVisualStyles ();
            Application.SetCompatibleTextRenderingDefault(false);

            Program.args = new CommandLineArguments();
            Program.log = new Log("Log.xml");


			Program.log.Add ("Program started");
            Program.config = new Config();
			Program.log.LogHistory = Program.config.LogHistory;

            Program.main_form = new MainForm();

            LmUtils.MessageBox.ParentForm = Program.main_form;
            YesNoBox.ParentForm = Program.main_form;

			try
			{
                Application.Run(Program.main_form);
                Program.log.Add("Quit program");
			}
			catch (Exception e)
			{
				Program.log.Add (e);
			}
		}
	}
}