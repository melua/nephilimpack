﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Data;
using System.Collections;
using System.Drawing;
using Microsoft.Win32;
using System.IO;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using System.Xml;
using System.Windows.Forms.Design;
using System.Net;
using LmUtils;

#endregion

namespace L2DatEncDec
{
	public class Config : LmUtils.Config
	{
		#region Constructors, destructor...

		public Config ()
			: base ("Config.xml")
		{
		}

		#endregion
		private const string Category_Global = "Global parameters";
		private const string Category_LineAge = "LineAge";

        #region Save, load and defaults

        public override void Reload()
        {
            base.Reload();

            if (this.xml.Root.ChildNodes.Count == 0)
            {
                Program.log.Add("No configuration file was found. Default settings will be used", LmUtils.LogLevel.Warning);
                this.Defaults();
            }

            if (this.inited)
                Program.main_form.Config_Load();
        }

        public override void Save()
        {
            try
            {
                base.Save();
            }
            catch (Exception e)
            {
                Program.log.Add("Error saving configuration settings", e);
            }
        }

        #endregion

		#region Editors

		class LineAgeDirectoryFolderBrowserEditor : UITypeEditor
		{
			public override UITypeEditorEditStyle GetEditStyle (ITypeDescriptorContext context)
			{
				return UITypeEditorEditStyle.Modal;
			}

			public override object EditValue (ITypeDescriptorContext context, IServiceProvider provider, object value)
			{
				Program.config.LoadLastFolder (Program.main_form.folder_browser_lineage_directory, "folder_browser_lineage_directory");
				Program.main_form.folder_browser_lineage_directory.SelectedPath = value.ToString ();

				if (Program.main_form.folder_browser_lineage_directory.ShowDialog () == DialogResult.OK)
				{
					Program.config.SaveLastFolder (Program.main_form.folder_browser_lineage_directory, "folder_browser_lineage_directory");
					return Program.main_form.folder_browser_lineage_directory.SelectedPath;
				}

				return value;
			}
		}

		public class ColorEditor : UITypeEditor
		{
			public override UITypeEditorEditStyle GetEditStyle (ITypeDescriptorContext context)
			{
				return UITypeEditorEditStyle.Modal;
			}

			public override object EditValue (ITypeDescriptorContext context, IServiceProvider provider, object value)
			{
				Program.config.LoadFormState (Program.main_form.color_dialog_main, "color_dialog_main");

				string color_str = (string) value;
				if (!String.IsNullOrEmpty (color_str))
					Program.main_form.color_dialog_main.Color = ConvertUtilities.HtmlColorToColor (color_str);

				if (Program.main_form.color_dialog_main.ShowDialog () == DialogResult.OK)
				{
					Program.config.SaveFormState (Program.main_form.color_dialog_main, "color_dialog_main");
					return ConvertUtilities.ColorToHtmlColor (Program.main_form.color_dialog_main.Color);
				}

				return value;
			}
		}

		#endregion

		#region Global

		[DisplayName ("Log history"), Description ("Amount of last logs to store"), Category (Category_Global), DefaultValue (30)]
		public int LogHistory
		{
			get
			{
				try
				{
					return Convert.ToInt32 (this.xml["Global.LogHistory"]);
				}
				catch
				{
					return (int) this.GetDefault ("LogHistory");
				}
			}
			set
			{
				this.xml["Global.LogHistory"] = value.ToString ();

				if (this.inited)
				{
					Program.log.LogHistory = value;
				}
			}
		}

        [DisplayName("Text Encoding"), Description("Encoding of read and written text file"), Category(Category_Global), DefaultValue("utf-8")]
        public string TextEncoding
        {
            get
            {
                try
                {
                    return this.xml["Global.TextEncoding"];
                }
                catch
                {
                    return (string)this.GetDefault("TextEncoding");
                }
            }
            set
            {
                this.xml["Global.TextEncoding"] = value;
            }
        }

		#endregion

		#region LineAge

		[DisplayName ("LineAge directory"), Description ("Directory where LineAge installed"), Category (Category_LineAge), DefaultValue (""), Editor (typeof (Config.LineAgeDirectoryFolderBrowserEditor), typeof (System.Drawing.Design.UITypeEditor))]
		public string LineAgeDirectory
		{
			get
			{
				try
				{
					return this.xml["LineAge.Directory"];
				}
				catch
				{
					return (string) this.GetDefault ("LineAgeDirectory");
				}
			}
			set
			{
				this.xml["LineAge.Directory"] = value;
			}
		}

		[DisplayName ("Save BAK files"), Description ("Set to 'True' if you want program to save bak-files on each save"), Category (Category_LineAge), DefaultValue (true)]
		public bool LineAgeSaveBakFiles
		{
			get
			{
				try
				{
					return Convert.ToBoolean (this.xml["LineAge.SaveBakFiles"]);
				}
				catch
				{
					return (bool) this.GetDefault ("LineAgeSaveBakFiles");
				}
			}
			set
			{
				this.xml["LineAge.SaveBakFiles"] = value.ToString ();
			}
		}

        [DisplayName("DAT File Names"), Description("Declare of LineAge DAT File Names"), Category(Category_LineAge), DefaultValue(true)]
        public string LineAgeDatFileNames
        {
            get
            {
                try
                {
                    return this.xml["LineAge.DatFileNames"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAgeDatFileNames");
                }
            }
            set
            {
                this.xml["LineAge.DatFileNames"] = value;
            }
        }

        [DisplayName("LineAge action names file"), Description("Path (based on LA2 installed dir) to the action names data file"), Category(Category_LineAge), DefaultValue(@"system\actionname-j.dat")]
        public string LineAge_actionname
        {
            get
            {
                try
                {
                    return this.xml["LineAge.actionname"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_actionname");
                }
            }
            set
            {
                this.xml["LineAge.actionname"] = value;
            }
        }

        [DisplayName("LineAge castle names file"), Description("Path (based on LA2 installed dir) to the castle names data file"), Category(Category_LineAge), DefaultValue(@"system\castlename-j.dat")]
        public string LineAge_castlename
        {
            get
            {
                try
                {
                    return this.xml["LineAge.castlename"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_castlename");
                }
            }
            set
            {
                this.xml["LineAge.castlename"] = value;
            }
        }

        [DisplayName("LineAge command names file"), Description("Path (based on LA2 installed dir) to the command names data file"), Category(Category_LineAge), DefaultValue(@"system\commandname-j.dat")]
        public string LineAge_commandname
        {
            get
            {
                try
                {
                    return this.xml["LineAge.commandname"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_LineAge_commandname");
                }
            }
            set
            {
                this.xml["LineAge.LineAge_commandname"] = value;
            }
        }

        [DisplayName("LineAge gametip file"), Description("Path (based on LA2 installed dir) to the gametip data file"), Category(Category_LineAge), DefaultValue(@"system\gametip-j.dat")]
        public string LineAge_gametip
        {
            get
            {
                try
                {
                    return this.xml["LineAge.gametip"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_LineAge_gametip");
                }
            }
            set
            {
                this.xml["LineAge.LineAge_gametip"] = value;
            }
        }

        [DisplayName("LineAge huntingzone names file"), Description("Path (based on LA2 installed dir) to the huntingzone data file"), Category(Category_LineAge), DefaultValue(@"system\huntingzone-j.dat")]
        public string LineAge_huntingzone
        {
            get
            {
                try
                {
                    return this.xml["LineAge.huntingzone"];
                }
                catch
                {
                    return (string)this.GetDefault("huntingzone");
                }
            }
            set
            {
                this.xml["LineAge.huntingzone"] = value;
            }
        }

        [DisplayName("LineAge item names file"), Description("Path (based on LA2 installed dir) to the item names data file"), Category(Category_LineAge), DefaultValue(@"system\itemname-j.dat")]
        public string LineAge_itemname
        {
            get
            {
                try
                {
                    return this.xml["LineAge.itemname"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_itemname");
                }
            }
            set
            {
                this.xml["LineAge.itemname"] = value;
            }
        }

        [DisplayName("LineAge NPC names file"), Description("Path (based on LA2 installed dir) to the NPC names data file"), Category(Category_LineAge), DefaultValue(@"system\npcname-j.dat")]
        public string LineAge_npcname
        {
            get
            {
                try
                {
                    return this.xml["LineAge.npcname"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_npcname");
                }
            }
            set
            {
                this.xml["LineAge.npcname"] = value;
            }
        }

        [DisplayName("LineAge Obscenes string file"), Description("Path (based on LA2 installed dir) to the Obscenes data file"), Category(Category_LineAge), DefaultValue(@"system\obscene-j.dat")]
        public string LineAge_obscene
        {
            get
            {
                try
                {
                    return this.xml["LineAge.obscene"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_obscene");
                }
            }
            set
            {
                this.xml["LineAge.obscene"] = value;
            }
        }

        [DisplayName("LineAge Quest names file"), Description("Path (based on LA2 installed dir) to the Quest names data file"), Category(Category_LineAge), DefaultValue(@"system\questname-j.dat")]
        public string LineAge_questname
        {
            get
            {
                try
                {
                    return this.xml["LineAge.questname"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_questname");
                }
            }
            set
            {
                this.xml["LineAge.questname"] = value;
            }
        }

        [DisplayName("LineAge RaidData file"), Description("Path (based on LA2 installed dir) to the raid data file"), Category(Category_LineAge), DefaultValue(@"system\raiddata-j.dat")]
        public string LineAge_raiddata
        {
            get
            {
                try
                {
                    return this.xml["LineAge.raiddata"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_raiddata");
                }
            }
            set
            {
                this.xml["LineAge.raiddata"] = value;
            }
        }

        [DisplayName("LineAge Recipe file"), Description("Path (based on LA2 installed dir) to the recipe data file"), Category(Category_LineAge), DefaultValue(@"system\recipe-c.dat")]
        public string LineAge_recipe
        {
            get
            {
                try
                {
                    return this.xml["LineAge.recipe"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_recipe");
                }
            }
            set
            {
                this.xml["LineAge.recipe"] = value;
            }
        }

        [DisplayName("LineAge Server names file"), Description("Path (based on LA2 installed dir) to the servername data file"), Category(Category_LineAge), DefaultValue(@"system\servername-j.dat")]
        public string LineAge_servername
        {
            get
            {
                try
                {
                    return this.xml["LineAge.servername"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_servername");
                }
            }
            set
            {
                this.xml["LineAge.servername"] = value;
            }
        }

        [DisplayName("LineAge Skill Names file"), Description("Path (based on LA2 installed dir) to the skillname data file"), Category(Category_LineAge), DefaultValue(@"system\skillname-j.dat")]
        public string LineAge_skillname
        {
            get
            {
                try
                {
                    return this.xml["LineAge.skillname"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_skillname");
                }
            }
            set
            {
                this.xml["LineAge.skillname"] = value;
            }
        }

        [DisplayName("LineAge staticobject data file"), Description("Path (based on LA2 installed dir) to the staticobject data file"), Category(Category_LineAge), DefaultValue(@"system\staticobject-j.dat")]
        public string LineAge_staticobject
        {
            get
            {
                try
                {
                    return this.xml["LineAge.staticobject"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_staticobject");
                }
            }
            set
            {
                this.xml["LineAge.staticobject"] = value;
            }
        }

        [DisplayName("LineAge system messages file"), Description("Path (based on LA2 installed dir) to the system messages data file"), Category(Category_LineAge), DefaultValue(@"system\systemmsg-j.dat")]
		public string LineAge_systemmsg
		{
			get
			{
				try
				{
					return this.xml["LineAge.systemmsg"];
				}
				catch
				{
					return (string) this.GetDefault ("LineAge_systemmsg");
				}
			}
			set
			{
				this.xml["LineAge.systemmsg"] = value;
			}
		}

        [DisplayName("LineAge system strings file"), Description("Path (based on LA2 installed dir) to the system strings data file"), Category(Category_LineAge), DefaultValue(@"system\sysstring-j.dat")]
        public string LineAge_sysstring
        {
            get
            {
                try
                {
                    return this.xml["LineAge.sysstring"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_sysstring");
                }
            }
            set
            {
                this.xml["LineAge.sysstring"] = value;
            }
        }

        [DisplayName("LineAge weapongrp file"), Description("Path (based on LA2 installed dir) to the weapongrp data file"), Category(Category_LineAge), DefaultValue(@"system\weapongrp.dat")]
        public string LineAge_weapongrp
        {
            get
            {
                try
                {
                    return this.xml["LineAge.weapongrp"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_weapongrp");
                }
            }
            set
            {
                this.xml["LineAge.weapongrp"] = value;
            }
        }

        [DisplayName("LineAge zone names file"), Description("Path (based on LA2 installed dir) to the zone names data file"), Category(Category_LineAge), DefaultValue(@"system\zonename-j.dat")]
        public string LineAge_zonename
        {
            get
            {
                try
                {
                    return this.xml["LineAge.zonename"];
                }
                catch
                {
                    return (string)this.GetDefault("LineAge_zonename");
                }
            }
            set
            {
                this.xml["LineAge.zonename"] = value;
            }
        }

        [DisplayName("Encrypt after save"), Description("Encrypt files with specified parameters after save (set to empty string to disable encryption after save). Se l2encdec documentation for more info. Example: -h 413"), Category(Category_LineAge), DefaultValue("-h 413")]
		public string LineAge_EncryptParameters
		{
			get
			{
				try
				{
					return this.xml["LineAge.EncryptParameters"];
				}
				catch
				{
					return (string) this.GetDefault ("LineAge_EncryptParameters");
				}
			}
			set
			{
				this.xml["LineAge.EncryptParameters"] = value;
			}
		}

		#endregion
	}
}