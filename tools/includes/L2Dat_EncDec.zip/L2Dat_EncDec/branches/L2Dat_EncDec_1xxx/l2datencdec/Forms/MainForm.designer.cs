﻿namespace L2DatEncDec
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.LoadBtn = new System.Windows.Forms.Button();
            this.List_Items = new System.Windows.Forms.ListView();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.folder_browser_lineage_directory = new System.Windows.Forms.FolderBrowserDialog();
            this.FileNameCombo = new System.Windows.Forms.ComboBox();
            this.ExpBtn = new System.Windows.Forms.Button();
            this.ExportDialog = new System.Windows.Forms.SaveFileDialog();
            this.ImpBtn = new System.Windows.Forms.Button();
            this.ImportDialog = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.chronicleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ChrSetMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ChrSetMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ChrSetMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ChrSetMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ChrSetMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuChgFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LoadBtn
            // 
            this.LoadBtn.Enabled = false;
            this.LoadBtn.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LoadBtn.Location = new System.Drawing.Point(168, 31);
            this.LoadBtn.Name = "LoadBtn";
            this.LoadBtn.Size = new System.Drawing.Size(107, 37);
            this.LoadBtn.TabIndex = 0;
            this.LoadBtn.Text = "Load";
            this.LoadBtn.UseVisualStyleBackColor = true;
            this.LoadBtn.Click += new System.EventHandler(this.LoadBtn_Click);
            // 
            // List_Items
            // 
            this.List_Items.Enabled = false;
            this.List_Items.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.List_Items.FullRowSelect = true;
            this.List_Items.GridLines = true;
            this.List_Items.Location = new System.Drawing.Point(13, 83);
            this.List_Items.Name = "List_Items";
            this.List_Items.Size = new System.Drawing.Size(722, 307);
            this.List_Items.TabIndex = 1;
            this.List_Items.UseCompatibleStateImageBehavior = false;
            this.List_Items.View = System.Windows.Forms.View.Details;
            this.List_Items.VirtualMode = true;
            this.List_Items.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.List_Items_MouseDoubleClick);
            this.List_Items.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this.List_Items_RetrieveVirtualItem);
            this.List_Items.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.List_Items_ItemSelectionChanged);
            // 
            // SaveBtn
            // 
            this.SaveBtn.Enabled = false;
            this.SaveBtn.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.SaveBtn.Location = new System.Drawing.Point(281, 31);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(104, 37);
            this.SaveBtn.TabIndex = 2;
            this.SaveBtn.Text = "Save";
            this.SaveBtn.UseVisualStyleBackColor = true;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // folder_browser_lineage_directory
            // 
            this.folder_browser_lineage_directory.Description = "Choose directory where LineAge installed";
            this.folder_browser_lineage_directory.ShowNewFolderButton = false;
            // 
            // FileNameCombo
            // 
            this.FileNameCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FileNameCombo.FormattingEnabled = true;
            this.FileNameCombo.Location = new System.Drawing.Point(13, 42);
            this.FileNameCombo.Name = "FileNameCombo";
            this.FileNameCombo.Size = new System.Drawing.Size(145, 20);
            this.FileNameCombo.TabIndex = 4;
            this.FileNameCombo.SelectedIndexChanged += new System.EventHandler(this.FileNameCombo_SelectedIndexChanged);
            // 
            // ExpBtn
            // 
            this.ExpBtn.Enabled = false;
            this.ExpBtn.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.ExpBtn.Location = new System.Drawing.Point(499, 31);
            this.ExpBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ExpBtn.Name = "ExpBtn";
            this.ExpBtn.Size = new System.Drawing.Size(102, 37);
            this.ExpBtn.TabIndex = 5;
            this.ExpBtn.Text = "Export";
            this.ExpBtn.UseVisualStyleBackColor = true;
            this.ExpBtn.Click += new System.EventHandler(this.ExpBtn_Click);
            // 
            // ImpBtn
            // 
            this.ImpBtn.Enabled = false;
            this.ImpBtn.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.ImpBtn.Location = new System.Drawing.Point(391, 31);
            this.ImpBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ImpBtn.Name = "ImpBtn";
            this.ImpBtn.Size = new System.Drawing.Size(102, 37);
            this.ImpBtn.TabIndex = 6;
            this.ImpBtn.Text = "Import";
            this.ImpBtn.UseVisualStyleBackColor = true;
            this.ImpBtn.Click += new System.EventHandler(this.ImpBtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuExit,
            this.chronicleToolStripMenuItem,
            this.MenuChgFolder,
            this.MenuAbout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(748, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MenuExit
            // 
            this.MenuExit.Name = "MenuExit";
            this.MenuExit.Size = new System.Drawing.Size(37, 20);
            this.MenuExit.Text = "Exit";
            this.MenuExit.Click += new System.EventHandler(this.MenuExit_Click);
            // 
            // chronicleToolStripMenuItem
            // 
            this.chronicleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ChrSetMenuItem1,
            this.ChrSetMenuItem2,
            this.ChrSetMenuItem3,
            this.ChrSetMenuItem4,
            this.ChrSetMenuItem5});
            this.chronicleToolStripMenuItem.Name = "chronicleToolStripMenuItem";
            this.chronicleToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.chronicleToolStripMenuItem.Text = "ChronicleSetting";
            // 
            // ChrSetMenuItem1
            // 
            this.ChrSetMenuItem1.Enabled = false;
            this.ChrSetMenuItem1.Name = "ChrSetMenuItem1";
            this.ChrSetMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.ChrSetMenuItem1.Text = "Chronicle 3";
            this.ChrSetMenuItem1.Click += new System.EventHandler(this.ChronicleSettingMenuItem_Click);
            // 
            // ChrSetMenuItem2
            // 
            this.ChrSetMenuItem2.Enabled = false;
            this.ChrSetMenuItem2.Name = "ChrSetMenuItem2";
            this.ChrSetMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.ChrSetMenuItem2.Text = "Chronicle 4";
            this.ChrSetMenuItem2.Click += new System.EventHandler(this.ChronicleSettingMenuItem_Click);
            // 
            // ChrSetMenuItem3
            // 
            this.ChrSetMenuItem3.Name = "ChrSetMenuItem3";
            this.ChrSetMenuItem3.Size = new System.Drawing.Size(158, 22);
            this.ChrSetMenuItem3.Text = "Chronicle 5";
            this.ChrSetMenuItem3.Click += new System.EventHandler(this.ChronicleSettingMenuItem_Click);
            // 
            // ChrSetMenuItem4
            // 
            this.ChrSetMenuItem4.Name = "ChrSetMenuItem4";
            this.ChrSetMenuItem4.Size = new System.Drawing.Size(158, 22);
            this.ChrSetMenuItem4.Text = "Interlude";
            this.ChrSetMenuItem4.Click += new System.EventHandler(this.ChronicleSettingMenuItem_Click);
            // 
            // ChrSetMenuItem5
            // 
            this.ChrSetMenuItem5.Checked = true;
            this.ChrSetMenuItem5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChrSetMenuItem5.Name = "ChrSetMenuItem5";
            this.ChrSetMenuItem5.Size = new System.Drawing.Size(158, 22);
            this.ChrSetMenuItem5.Text = "Chaotic Throne 1";
            this.ChrSetMenuItem5.Click += new System.EventHandler(this.ChronicleSettingMenuItem_Click);
            // 
            // MenuChgFolder
            // 
            this.MenuChgFolder.Name = "MenuChgFolder";
            this.MenuChgFolder.Size = new System.Drawing.Size(87, 20);
            this.MenuChgFolder.Text = "ChangeFolder";
            this.MenuChgFolder.Click += new System.EventHandler(this.MenuChgFolder_Click);
            // 
            // MenuAbout
            // 
            this.MenuAbout.Name = "MenuAbout";
            this.MenuAbout.Size = new System.Drawing.Size(47, 20);
            this.MenuAbout.Text = "About";
            this.MenuAbout.Click += new System.EventHandler(this.MenuAbout_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 401);
            this.Controls.Add(this.ImpBtn);
            this.Controls.Add(this.ExpBtn);
            this.Controls.Add(this.FileNameCombo);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.List_Items);
            this.Controls.Add(this.LoadBtn);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "L2Dat_EncDec";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ColorDialog color_dialog_main;
        public System.Windows.Forms.FolderBrowserDialog folder_browser_lineage_directory;
        private System.Windows.Forms.Button LoadBtn;
        private System.Windows.Forms.ListView List_Items;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.ComboBox FileNameCombo;
        private System.Windows.Forms.Button ExpBtn;
        private System.Windows.Forms.SaveFileDialog ExportDialog;
        private System.Windows.Forms.OpenFileDialog ImportDialog;
        private System.Windows.Forms.Button ImpBtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuChgFolder;
        private System.Windows.Forms.ToolStripMenuItem MenuExit;
        private System.Windows.Forms.ToolStripMenuItem MenuAbout;
        private System.Windows.Forms.ToolStripMenuItem chronicleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ChrSetMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ChrSetMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ChrSetMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem ChrSetMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem ChrSetMenuItem5;
    }
}

