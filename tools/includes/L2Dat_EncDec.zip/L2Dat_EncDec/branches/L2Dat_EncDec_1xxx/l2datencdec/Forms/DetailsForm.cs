using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using L2DatEncDec;
using L2DatEncDec.Parsers;
using LmUtils;

namespace L2DatEncDec.Forms
{
    public partial class DetailsForm : Form
    {
        public DetailsForm()
        {
            InitializeComponent();
        }

        private void InputForm_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < Program.main_form.ColumnsTitle.Length; i++)
            {
                foreach (Control ctl in this.Controls)
                {
                    if (ctl.Name == "label" + (i + 1))
                    {
                        ctl.Text = Program.main_form.ColumnsTitle[i];
                        ctl.Enabled = true;
                    }
                    if (ctl.Name == "text" + (i + 1))
                    {
                        ctl.Enabled = true;
                    }
                }
            }

            if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
            {
                this.text1.Text = Program.main_form.selectedActions.tags.ToString();
                this.text2.Text = Program.main_form.selectedActions.id.ToString();
                this.text3.Text = Program.main_form.selectedActions.type.ToString();
                this.text4.Text = Program.main_form.selectedActions.category.ToString();
                this.text5.Text = Program.main_form.selectedActions.cat2_ids;
                this.text6.Text = Program.main_form.selectedActions.cmd;
                this.text7.Text = Program.main_form.selectedActions.icon;
                this.text8.Text = Program.main_form.selectedActions.name;
                this.text9.Text = Program.main_form.selectedActions.desc;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
            {
                this.text1.Text = Program.main_form.selectedCastles.nbr.ToString();
                this.text2.Text = Program.main_form.selectedCastles.tags.ToString();
                this.text3.Text = Program.main_form.selectedCastles.id.ToString();
                this.text4.Text = Program.main_form.selectedCastles.castle_name;
                this.text5.Text = Program.main_form.selectedCastles.location;
                this.text6.Text = Program.main_form.selectedCastles.desc;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
            {
                this.text1.Text = Program.main_form.selectedCommands.nbr.ToString();
                this.text2.Text = Program.main_form.selectedCommands.id.ToString();
                this.text3.Text = Program.main_form.selectedCommands.name;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
            {
                this.text1.Text = Program.main_form.selectedGameTips.id.ToString();
                this.text2.Text = Program.main_form.selectedGameTips.tmp1.ToString();
                this.text3.Text = Program.main_form.selectedGameTips.tmp2.ToString();
                this.text4.Text = Program.main_form.selectedGameTips.enable.ToString();
                this.text5.Text = Program.main_form.selectedGameTips.tip;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
            {
                this.text1.Text = Program.main_form.selectedHuntingZones.id.ToString();
                this.text2.Text = Program.main_form.selectedHuntingZones.hunting_type.ToString();
                this.text3.Text = Program.main_form.selectedHuntingZones.level.ToString();
                this.text4.Text = Program.main_form.selectedHuntingZones.loc_x.ToString();
                this.text5.Text = Program.main_form.selectedHuntingZones.loc_y.ToString();
                this.text6.Text = Program.main_form.selectedHuntingZones.loc_z.ToString();
                this.text7.Text = Program.main_form.selectedHuntingZones.affiliated_area_id.ToString();
                this.text8.Text = Program.main_form.selectedHuntingZones.name;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
            {
                this.text1.Text = Program.main_form.selectedItems.id.ToString();
                this.text2.Text = Program.main_form.selectedItems.name;
                this.text3.Text = Program.main_form.selectedItems.additionalname;
                this.text4.Text = Program.main_form.selectedItems.description;
                this.text5.Text = Program.main_form.selectedItems.set_ids;
                this.text6.Text = Program.main_form.selectedItems.set_bonus_desc;
                this.text7.Text = Program.main_form.selectedItems.set_extra_id;
                this.text8.Text = Program.main_form.selectedItems.set_extra_desc;
                this.text9.Text = Program.main_form.selectedItems.special_enchant_amount.ToString();
                this.text10.Text = Program.main_form.selectedItems.special_enchant_desc;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
            {
                this.text1.Text = Program.main_form.selectedNpcs.id.ToString();
                this.text2.Text = Program.main_form.selectedNpcs.name;
                this.text3.Text = Program.main_form.selectedNpcs.title;
                this.text4.Text = Program.main_form.selectedNpcs.ColorStr;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
            {
                this.text1.Text = Program.main_form.selectedObscenes.id.ToString();
                this.text2.Text = Program.main_form.selectedObscenes.text;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
            {
                this.text1.Text = Program.main_form.selectedQuests.quest_id.ToString();
                this.text2.Text = Program.main_form.selectedQuests.quest_prog.ToString();
                this.text3.Text = Program.main_form.selectedQuests.main_name;
                this.text4.Text = Program.main_form.selectedQuests.prog_name;
                this.text5.Text = Program.main_form.selectedQuests.description;
                this.text6.Text = Program.main_form.selectedQuests.entity_name;
                this.text7.Text = Program.main_form.selectedQuests.race_restricion;
                this.text8.Text = Program.main_form.selectedQuests.short_description;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
            {
                this.text1.Text = Program.main_form.selectedRaids.id.ToString();
                this.text2.Text = Program.main_form.selectedRaids.npc_id.ToString();
                this.text3.Text = Program.main_form.selectedRaids.npc_level.ToString();
                this.text4.Text = Program.main_form.selectedRaids.affiliated_area_id.ToString();
                this.text5.Text = Program.main_form.selectedRaids.loc_x.ToString();
                this.text6.Text = Program.main_form.selectedRaids.loc_y.ToString();
                this.text7.Text = Program.main_form.selectedRaids.loc_z.ToString();
                this.text8.Text = Program.main_form.selectedRaids.raid_desc;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
            {
                this.text1.Text = Program.main_form.selectedRecipes.name;
                this.text2.Text = Program.main_form.selectedRecipes.id_mk.ToString();
                this.text3.Text = Program.main_form.selectedRecipes.id_recipe.ToString();
                this.text4.Text = Program.main_form.selectedRecipes.level.ToString();
                this.text5.Text = Program.main_form.selectedRecipes.materials;
                this.text6.Text = Program.main_form.selectedRecipes.id_item.ToString();
                this.text7.Text = Program.main_form.selectedRecipes.count.ToString();
                this.text8.Text = Program.main_form.selectedRecipes.mp_cost.ToString();
                this.text9.Text = Program.main_form.selectedRecipes.success_rate.ToString();
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
            {
                this.text1.Text = Program.main_form.selectedServers.server_id.ToString();
                this.text2.Text = Program.main_form.selectedServers.server_name;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
            {
                this.text1.Text = Program.main_form.selectedSkills.id.ToString();
                this.text2.Text = Program.main_form.selectedSkills.level.ToString();
                this.text3.Text = Program.main_form.selectedSkills.name;
                this.text4.Text = Program.main_form.selectedSkills.description;
                this.text5.Text = Program.main_form.selectedSkills.desc_add1;
                this.text6.Text = Program.main_form.selectedSkills.desc_add2;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
            {
                this.text1.Text = Program.main_form.selectedStaticObjects.id.ToString();
                this.text2.Text = Program.main_form.selectedStaticObjects.name;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
            {
                this.text1.Text = Program.main_form.selectedSysStrings.id.ToString();
                this.text2.Text = Program.main_form.selectedSysStrings.name;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
            {
                this.text1.Text = Program.main_form.selectedSystemMsgs.id.ToString();
                this.text2.Text = Program.main_form.selectedSystemMsgs.msg;
                this.text3.Text = Program.main_form.selectedSystemMsgs.group.ToString();
                this.text4.Text = Program.main_form.selectedSystemMsgs.ColorStr;
                this.text5.Text = Program.main_form.selectedSystemMsgs.sound;
                this.text6.Text = Program.main_form.selectedSystemMsgs.msg_ref;
            }
            else if (Program.main_form.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
            {
                this.text1.Text = Program.main_form.selectedZones.nbr.ToString();
                this.text2.Text = Program.main_form.selectedZones.zone_color_id.ToString();
                this.text3.Text = Program.main_form.selectedZones.x_world_grid.ToString();
                this.text4.Text = Program.main_form.selectedZones.y_world_grid.ToString();
                this.text5.Text = Program.main_form.selectedZones.top_z.ToString();
                this.text6.Text = Program.main_form.selectedZones.bottom_z.ToString();
                this.text7.Text = Program.main_form.selectedZones.zone_name;
                this.text8.Text = Program.main_form.selectedZones.map_name;
            }
            this.Left = (Program.main_form.Width - this.Width) / 2;
            this.Top = (Program.main_form.Height - this.Height) / 2;
        }

        private void OkBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}