using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Xml;
using System.Text;
using System.Windows.Forms;
using L2DatEncDec.Parsers;
using L2DatEncDec.Forms;
using LmUtils;

namespace L2DatEncDec
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
			this.Visible = false;
			this.SuspendLayout();

			try
			{
                this.Config_Load();
            }
            catch (Exception ex)
            {
                Program.log.Add(ex, true);
            }
            finally
            {
                this.Visible = true;
                this.ResumeLayout();

                this.Show();
                this.BringToFront();
                this.Activate();
            }
        }

        #region Config

        public void Config_Load()
        {
            // form and controls
            Program.config.LoadFormState(this, "main_form");

            if (!Directory.Exists(Program.config.LineAgeDirectory))
            {
                new LmUtils.MessageBox("LineAge System directory is not found or specification is wrong.\nPlease specify an effective LineAge System directory.");

                Program.config.LoadLastFolder(this.folder_browser_lineage_directory, "folder_browser_lineage_directory");
                if (this.folder_browser_lineage_directory.ShowDialog() == DialogResult.OK)
                {
                    Program.config.SaveLastFolder(this.folder_browser_lineage_directory, "folder_browser_lineage_directory");
                    Program.config.LineAgeDirectory = this.folder_browser_lineage_directory.SelectedPath;
                }
            }
            this.Text = Application.ProductName + " - " + Program.config.LineAgeDirectory;

            string[] TmpStr = Program.config.LineAgeDatFileNames.Split(new char[] {','});
            this.FileNameCombo.Items.AddRange(TmpStr);
        }

        private void Config_Save()
        {
            // form and controls
            Program.config.SaveFormState(this, "main_form");

            // config
            Program.config.Save();
        }

        #endregion

        internal List<ActionName.ActionNameInfo> Actions;
        public ActionName.ActionNameInfo selectedActions;
        internal List<CastleName.CastleNameInfo> Castles;
        public CastleName.CastleNameInfo selectedCastles;
        internal List<CommandName.CommandNameInfo> Commands;
        public CommandName.CommandNameInfo selectedCommands;
        internal List<GameTip.GameTipInfo> GameTips;
        public GameTip.GameTipInfo selectedGameTips;
        internal List<HuntingZone.HuntingZoneInfo> HuntingZones;
        public HuntingZone.HuntingZoneInfo selectedHuntingZones;
        internal List<ItemName.ItemNameInfo> Items;
        public ItemName.ItemNameInfo selectedItems;
        internal List<NpcName.NpcNameInfo> Npcs;
        public NpcName.NpcNameInfo selectedNpcs;
        internal List<Obscene.ObsceneInfo> Obscenes;
        public Obscene.ObsceneInfo selectedObscenes;
        internal List<QuestName.QuestNameInfo> Quests;
        public QuestName.QuestNameInfo selectedQuests;
        internal List<RaidData.RaidDataInfo> Raids;
        public RaidData.RaidDataInfo selectedRaids;
        internal List<Recipe.RecipeInfo> Recipes;
        public Recipe.RecipeInfo selectedRecipes;
        internal List<ServerName.ServerNameInfo> Servers;
        public ServerName.ServerNameInfo selectedServers;
        internal List<SkillName.SkillNameInfo> Skills;
        public SkillName.SkillNameInfo selectedSkills;
        internal List<StaticObject.StaticObjectInfo> StaticObjects;
        public StaticObject.StaticObjectInfo selectedStaticObjects;
        internal List<SysString.SysStringInfo> SysStrings;
        public SysString.SysStringInfo selectedSysStrings;
        internal List<SystemMsg.SystemMsgInfo> SystemMsgs;
        public SystemMsg.SystemMsgInfo selectedSystemMsgs;
        internal List<Weapongrp.WeapongrpInfo> Weapongrps;
        public Weapongrp.WeapongrpInfo selectedWeapongrps;
        internal List<ZoneName.ZoneNameInfo> Zones;
        public ZoneName.ZoneNameInfo selectedZones;
        internal int selectedListsIndex = 0;
        public string selectedComboName = "";
        public int selectedComboIndex = 0;
        public int selectedChronicleIdx = 5; // Default:Chaotic Throne 1
        public string[] ColumnsTitle;

        private void LoadBtn_Click(object sender, EventArgs e)
        {
            try
            {
                this.FileNameCombo.Enabled = false;
                this.List_Items.Enabled = false;
                this.Enabled = false;
                this.List_Items.BeginUpdate();
                this.List_Items.Items.Clear();

                if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_actionname, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Actions = ActionName.Parse(f);
                    f.Close();

                    if (this.Actions == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_castlename, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Castles = CastleName.Parse(f);
                    f.Close();

                    if (this.Castles == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_commandname, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Commands = CommandName.Parse(f);
                    f.Close();

                    if (this.Commands == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_gametip, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.GameTips = GameTip.Parse(f);
                    f.Close();

                    if (this.GameTips == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_huntingzone, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.HuntingZones = HuntingZone.Parse(f);
                    f.Close();

                    if (this.HuntingZones == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_itemname, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Items = ItemName.Parse(f);
                    f.Close();

                    if (this.Items == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_npcname, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Npcs = NpcName.Parse(f);
                    f.Close();

                    if (this.Npcs == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_obscene, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Obscenes = Obscene.Parse(f);
                    f.Close();

                    if (this.Obscenes == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_questname, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Quests = QuestName.Parse(f);
                    f.Close();

                    if (this.Quests == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_raiddata, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Raids = RaidData.Parse(f);
                    f.Close();

                    if (this.Raids == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_recipe, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Recipes = Recipe.Parse(f);
                    f.Close();

                    if (this.Recipes == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_servername, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Servers = ServerName.Parse(f);
                    f.Close();

                    if (this.Servers == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_skillname, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Skills = SkillName.Parse(f);
                    f.Close();

                    if (this.Skills == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_staticobject, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.StaticObjects = StaticObject.Parse(f);
                    f.Close();

                    if (this.StaticObjects == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_sysstring, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.SysStrings = SysString.Parse(f);
                    f.Close();

                    if (this.SysStrings == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_systemmsg, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.SystemMsgs = SystemMsg.Parse(f);
                    f.Close();

                    if (this.SystemMsgs == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_weapongrp, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();


                    this.Weapongrps = Weapongrp.Parse(f);
                    f.Close();

                    if (this.Weapongrps == null)
                        return;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
                {
                    BinaryReader f = L2EncDec.Decrypt(Program.config.LineAge_zonename, Encoding.Default);
                    if (f == null)
                        return;

                    this.List_Items.SelectedIndices.Clear();

                    this.Zones = ZoneName.Parse(f);
                    f.Close();

                    if (this.Zones == null)
                        return;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("It is a file not supported.");
                    return;
                }

                this.List_Items.Enabled = true;
                this.SaveBtn.Enabled = true;
                this.ExpBtn.Enabled = true;
                this.ListItems_Update();
                this.MainForm_Resize(sender, e);
                this.ListItems_Select();
            }
            catch (Exception ex)
            {
                Program.log.Add(ex, true);
            }
            finally
            {
                this.Enabled = true;
                this.FileNameCombo.Enabled = true;
                this.List_Items.EndUpdate();              
                this.List_Items.Focus();
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                this.FileNameCombo.Enabled = false;
                this.List_Items.Enabled = false;
                this.Enabled = false;
                if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_actionname);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    ActionName.Compile(f, this.Actions);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_actionname);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_castlename);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    CastleName.Compile(f, this.Castles);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_castlename);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_commandname);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    CommandName.Compile(f, this.Commands);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_commandname);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_gametip);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    GameTip.Compile(f, this.GameTips);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_gametip);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_huntingzone);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    HuntingZone.Compile(f, this.HuntingZones);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_huntingzone);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_itemname);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    ItemName.Compile(f, this.Items);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_itemname);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_npcname);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    NpcName.Compile(f, this.Npcs);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_npcname);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_obscene);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    Obscene.Compile(f, this.Obscenes);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_obscene);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_questname);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    QuestName.Compile(f, this.Quests);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_questname);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_raiddata);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    RaidData.Compile(f, this.Raids);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_raiddata);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_recipe);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    Recipe.Compile(f, this.Recipes);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_recipe);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_servername);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    ServerName.Compile(f, this.Servers);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_servername);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_skillname);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    SkillName.Compile(f, this.Skills);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_skillname);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_staticobject);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    StaticObject.Compile(f, this.StaticObjects);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_staticobject);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_sysstring);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    SysString.Compile(f, this.SysStrings);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_sysstring);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_systemmsg);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    SystemMsg.Compile(f, this.SystemMsgs);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_systemmsg);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_weapongrp);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    Weapongrp.Compile(f, this.Weapongrps);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_weapongrp);
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
                {
                    string fname = Path.Combine(Program.config.LineAgeDirectory, Program.config.LineAge_zonename);
                    if (Program.config.LineAgeSaveBakFiles)
                    {
                        try
                        {
                            File.Move(fname, Path.ChangeExtension(fname, ".bak"));
                        }
                        catch
                        {
                        }
                    }

                    BinaryWriter f = new BinaryWriter(File.OpenWrite(fname), Encoding.Default);
                    ZoneName.Compile(f, this.Zones);
                    f.Close();

                    L2EncDec.Encrypt(Program.config.LineAge_zonename);
                }
            }
            catch (Exception ex)
            {
                Program.log.Add(ex, true);
            }
            finally
            {
                this.Enabled = true;
                this.FileNameCombo.Enabled = true;
                this.List_Items.Enabled = true;
            }
            System.Windows.Forms.MessageBox.Show("Complete.");
        }

        private void List_Items_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            DetailsForm dlg = new DetailsForm();
            dlg.ShowDialog();
        }

        private void List_Items_RetrieveVirtualItem(object sender, RetrieveVirtualItemEventArgs e)
        {
            ListViewItem item = new ListViewItem();
            for (int i = 0; i < 100; i++)
                item.SubItems.Add("");
            if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
            {
                if (this.Actions == null)
                {
                    e.Item = item;
                    return;
                }
                ActionName.ActionNameInfo info = this.Actions[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListAction(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
            {
                if (this.Castles == null)
                {
                    e.Item = item;
                    return;
                }
                CastleName.CastleNameInfo info = this.Castles[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListCastle(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
            {
                if (this.Commands == null)
                {
                    e.Item = item;
                    return;
                }
                CommandName.CommandNameInfo info = this.Commands[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListCommand(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
            {
                if (this.GameTips == null)
                {
                    e.Item = item;
                    return;
                }
                GameTip.GameTipInfo info = this.GameTips[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListGameTip(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
            {
                if (this.HuntingZones == null)
                {
                    e.Item = item;
                    return;
                }
                HuntingZone.HuntingZoneInfo info = this.HuntingZones[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListHuntingZone(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
            {
                if (this.Items == null)
                {
                    e.Item = item;
                    return;
                }
                ItemName.ItemNameInfo info = this.Items[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListItem(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
            {
                if (this.Npcs == null)
                {
                    e.Item = item;
                    return;
                }
                NpcName.NpcNameInfo info = this.Npcs[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListNpc(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
            {
                if (this.Obscenes == null)
                {
                    e.Item = item;
                    return;
                }
                Obscene.ObsceneInfo info = this.Obscenes[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListObscene(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
            {
                if (this.Quests == null)
                {
                    e.Item = item;
                    return;
                }
                QuestName.QuestNameInfo info = this.Quests[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListQuest(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
            {
                if (this.Raids == null)
                {
                    e.Item = item;
                    return;
                }
                RaidData.RaidDataInfo info = this.Raids[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListRaid(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
            {
                if (this.Recipes == null)
                {
                    e.Item = item;
                    return;
                }
                Recipe.RecipeInfo info = this.Recipes[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListRecipe(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
            {
                if (this.Servers == null)
                {
                    e.Item = item;
                    return;
                }
                ServerName.ServerNameInfo info = this.Servers[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListServer(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
            {
                if (this.Skills == null)
                {
                    e.Item = item;
                    return;
                }
                SkillName.SkillNameInfo info = this.Skills[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListSkill(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
            {
                if (this.StaticObjects == null)
                {
                    e.Item = item;
                    return;
                }
                StaticObject.StaticObjectInfo info = this.StaticObjects[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListStaticObject(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
            {
                if (this.SysStrings == null)
                {
                    e.Item = item;
                    return;
                }
                SysString.SysStringInfo info = this.SysStrings[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListSysString(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
            {
                if (this.SystemMsgs == null)
                {
                    e.Item = item;
                    return;
                }
                SystemMsg.SystemMsgInfo info = this.SystemMsgs[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListSystemMsg(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
            {
                if (this.Weapongrps == null)
                {
                    e.Item = item;
                    return;
                }
                Weapongrp.WeapongrpInfo info = this.Weapongrps[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListWeapongrp(info);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
            {
                if (this.Zones == null)
                {
                    e.Item = item;
                    return;
                }
                ZoneName.ZoneNameInfo info = this.Zones[e.ItemIndex];
                item.Tag = info;
                info.Tag = item;
                this.UpdateListZone(info);
            }
            e.Item = item;
        }

        private void UpdateListAction(ActionName.ActionNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.tags.ToString();
            item.SubItems[1].Text = info.id.ToString();
            item.SubItems[2].Text = info.type.ToString();
            item.SubItems[3].Text = info.category.ToString();
            item.SubItems[4].Text = info.cat2_ids;
            item.SubItems[5].Text = info.cmd;
            item.SubItems[6].Text = info.icon;
            item.SubItems[7].Text = info.name;
            item.SubItems[8].Text = info.desc;
        }

        private void UpdateListCastle(CastleName.CastleNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.nbr.ToString();
            item.SubItems[1].Text = info.tags.ToString();
            item.SubItems[2].Text = info.id.ToString();
            item.SubItems[3].Text = info.castle_name;
            item.SubItems[4].Text = info.location;
            item.SubItems[5].Text = info.desc;
        }

        private void UpdateListCommand(CommandName.CommandNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.nbr.ToString();
            item.SubItems[1].Text = info.id.ToString();
            item.SubItems[2].Text = info.name;
        }

        private void UpdateListGameTip(GameTip.GameTipInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.tmp1.ToString();
            item.SubItems[2].Text = info.tmp2.ToString();
            item.SubItems[3].Text = info.enable.ToString();
            item.SubItems[4].Text = info.tip;
        }

        private void UpdateListHuntingZone(HuntingZone.HuntingZoneInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.hunting_type.ToString();
            item.SubItems[2].Text = info.level.ToString();
            item.SubItems[3].Text = info.loc_x.ToString();
            item.SubItems[4].Text = info.loc_y.ToString();
            item.SubItems[5].Text = info.loc_z.ToString();
            item.SubItems[6].Text = info.affiliated_area_id.ToString();
            item.SubItems[7].Text = info.name;
        }

        private void UpdateListItem(ItemName.ItemNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.name;
            item.SubItems[2].Text = info.additionalname;
            item.SubItems[3].Text = info.description;
            item.SubItems[4].Text = info.set_ids;
            item.SubItems[5].Text = info.set_bonus_desc;
            item.SubItems[6].Text = info.set_extra_id;
            item.SubItems[7].Text = info.set_extra_desc;
            item.SubItems[8].Text = info.special_enchant_amount.ToString();
            item.SubItems[9].Text = info.special_enchant_desc;
        }

        private void UpdateListNpc(NpcName.NpcNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.name;
            item.SubItems[2].Text = info.title;
            item.SubItems[3].Text = info.ColorStr;
        }

        private void UpdateListObscene(Obscene.ObsceneInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.text;
        }

        private void UpdateListQuest(QuestName.QuestNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.quest_id.ToString();
            item.SubItems[1].Text = info.quest_prog.ToString();
            item.SubItems[2].Text = info.main_name;
            item.SubItems[3].Text = info.prog_name;
            item.SubItems[4].Text = info.description;
            item.SubItems[5].Text = info.entity_name;
            item.SubItems[6].Text = info.race_restricion;
            item.SubItems[7].Text = info.short_description;
        }

        private void UpdateListRaid(RaidData.RaidDataInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.npc_id.ToString();
            item.SubItems[2].Text = info.npc_level.ToString();
            item.SubItems[3].Text = info.affiliated_area_id.ToString();
            item.SubItems[4].Text = info.loc_x.ToString();
            item.SubItems[5].Text = info.loc_y.ToString();
            item.SubItems[6].Text = info.loc_z.ToString();
            item.SubItems[7].Text = info.raid_desc;
        }

        private void UpdateListRecipe(Recipe.RecipeInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.name;
            item.SubItems[1].Text = info.id_mk.ToString();
            item.SubItems[2].Text = info.id_recipe.ToString();
            item.SubItems[3].Text = info.level.ToString();
            item.SubItems[4].Text = info.materials;
            item.SubItems[5].Text = info.id_item.ToString();
            item.SubItems[6].Text = info.count.ToString();
            item.SubItems[7].Text = info.mp_cost.ToString();
            item.SubItems[8].Text = info.success_rate.ToString();
        }

        private void UpdateListServer(ServerName.ServerNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.server_id.ToString();
            item.SubItems[1].Text = info.server_name;
        }

        private void UpdateListSkill(SkillName.SkillNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.level.ToString();
            item.SubItems[2].Text = info.name;
            item.SubItems[3].Text = info.description;
            item.SubItems[4].Text = info.desc_add1;
            item.SubItems[5].Text = info.desc_add2;
        }

        private void UpdateListStaticObject(StaticObject.StaticObjectInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.name;
        }

        private void UpdateListSysString(SysString.SysStringInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.name;
        }

        private void UpdateListSystemMsg(SystemMsg.SystemMsgInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.id.ToString();
            item.SubItems[1].Text = info.msg;
            item.SubItems[2].Text = info.group.ToString();
            item.SubItems[3].Text = info.ColorStr;
            item.SubItems[4].Text = info.sound;
            item.SubItems[5].Text = info.msg_ref;
            item.SubItems[6].Text = info.sub_msg;
            item.SubItems[7].Text = info.type;
        }

        private void UpdateListWeapongrp(Weapongrp.WeapongrpInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.tags.ToString();
            item.SubItems[1].Text = info.id.ToString();
            item.SubItems[2].Text = info.drop_type.ToString();
            item.SubItems[3].Text = info.drop_anim_type.ToString();
            item.SubItems[4].Text = info.drop_radius.ToString();
            item.SubItems[5].Text = info.drop_height.ToString();
            item.SubItems[6].Text = info.UNK_0.ToString();
            item.SubItems[7].Text = info.drop_meshtex1;
            item.SubItems[8].Text = info.drop_meshtex2;
            item.SubItems[9].Text = info.icon1;
            item.SubItems[10].Text = info.icon2;
            item.SubItems[11].Text = info.icon3;
            item.SubItems[12].Text = info.icon4;
            item.SubItems[13].Text = info.icon5;
            item.SubItems[14].Text = info.icon6;
            item.SubItems[15].Text = info.icon7;
            item.SubItems[16].Text = info.icon8;
            item.SubItems[17].Text = info.icon9;
            item.SubItems[18].Text = info.durability.ToString();
            item.SubItems[19].Text = info.weight.ToString();
            item.SubItems[20].Text = info.material.ToString();
            item.SubItems[21].Text = info.crystallizable.ToString();
            item.SubItems[22].Text = info.projectile.ToString();
            item.SubItems[23].Text = info.UNK_1;
            item.SubItems[24].Text = info.body_part.ToString();
            item.SubItems[25].Text = info.handness.ToString();
            item.SubItems[26].Text = info.cntm.ToString();
            item.SubItems[27].Text = info.mesh;
            item.SubItems[28].Text = info.cntt.ToString();
            item.SubItems[29].Text = info.text;
            item.SubItems[30].Text = info.item_sound_cnt.ToString();
            item.SubItems[31].Text = info.item_sound;
            item.SubItems[32].Text = info.drop_sound;
            item.SubItems[33].Text = info.equip_sound;
            item.SubItems[34].Text = info.effect;
            item.SubItems[35].Text = info.random_damage.ToString();
            item.SubItems[36].Text = info.patt.ToString();
            item.SubItems[37].Text = info.matt.ToString();
            item.SubItems[38].Text = info.weapon_type.ToString();
            item.SubItems[39].Text = info.crystal_type.ToString();
            item.SubItems[40].Text = info.critical.ToString();
            item.SubItems[41].Text = info.hit_mod.ToString();
            item.SubItems[42].Text = info.avoid_mod.ToString();
            item.SubItems[43].Text = info.shield_pdef.ToString();
            item.SubItems[44].Text = info.shield_rate.ToString();
            item.SubItems[45].Text = info.speed.ToString();
            item.SubItems[46].Text = info.mp_consume.ToString();
            item.SubItems[47].Text = info.SS_count.ToString();
            item.SubItems[48].Text = info.SPS_count.ToString();
            item.SubItems[49].Text = info.curvature.ToString();
            item.SubItems[50].Text = info.UNK_2.ToString();
            item.SubItems[51].Text = info.is_hero.ToString();
            item.SubItems[52].Text = info.UNK_3.ToString();
            item.SubItems[53].Text = info.effA;
            item.SubItems[54].Text = info.effB;
            item.SubItems[55].Text = info.junk1A_1.ToString();
            item.SubItems[56].Text = info.junk1A_2.ToString();
            item.SubItems[57].Text = info.junk1A_3.ToString();
            item.SubItems[58].Text = info.junk1A_4.ToString();
            item.SubItems[59].Text = info.junk1A_5.ToString();
            item.SubItems[60].Text = info.junk1B_1.ToString();
            item.SubItems[61].Text = info.junk1B_2.ToString();
            item.SubItems[62].Text = info.junk1B_3.ToString();
            item.SubItems[63].Text = info.junk1B_4.ToString();
            item.SubItems[64].Text = info.junk1B_5.ToString();
            item.SubItems[65].Text = info.rangeA;
            item.SubItems[66].Text = info.rangeB;
            item.SubItems[67].Text = info.junk2A_1.ToString();
            item.SubItems[68].Text = info.junk2A_2.ToString();
            item.SubItems[69].Text = info.junk2A_3.ToString();
            item.SubItems[70].Text = info.junk2A_4.ToString();
            item.SubItems[71].Text = info.junk2A_5.ToString();
            item.SubItems[72].Text = info.junk2A_6.ToString();
            item.SubItems[73].Text = info.junk2B_1.ToString();
            item.SubItems[74].Text = info.junk2B_2.ToString();
            item.SubItems[75].Text = info.junk2B_3.ToString();
            item.SubItems[76].Text = info.junk2B_4.ToString();
            item.SubItems[77].Text = info.junk2B_5.ToString();
            item.SubItems[78].Text = info.junk2B_6.ToString();
            item.SubItems[79].Text = info.junk3_1.ToString();
            item.SubItems[80].Text = info.junk3_2.ToString();
            item.SubItems[81].Text = info.junk3_3.ToString();
            item.SubItems[82].Text = info.junk3_4.ToString();
            item.SubItems[83].Text = info.icons1;
            item.SubItems[84].Text = info.icons2;
            item.SubItems[85].Text = info.icons3;
            item.SubItems[86].Text = info.icons4;
        }

        private void UpdateListZone(ZoneName.ZoneNameInfo info)
        {
            ListViewItem item = info.Tag as ListViewItem;

            item.Text = info.nbr.ToString();
            item.SubItems[1].Text = info.zone_color_id.ToString();
            item.SubItems[2].Text = info.x_world_grid.ToString();
            item.SubItems[3].Text = info.y_world_grid.ToString();
            item.SubItems[4].Text = info.top_z.ToString();
            item.SubItems[5].Text = info.bottom_z.ToString();
            item.SubItems[6].Text = info.zone_name;
            item.SubItems[7].Text = info.map_name;
        }

        private void List_Items_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
            {
                if (this.Actions == null)
                    return;
                ActionName.ActionNameInfo info = this.Actions[e.ItemIndex];
                this.selectedActions = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedActions[id]:" + selectedActions.id);
                Console.Out.WriteLine("selectedActions[name]:" + selectedActions.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
            {
                if (this.Castles == null)
                    return;
                CastleName.CastleNameInfo info = this.Castles[e.ItemIndex];
                this.selectedCastles = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedCastles[id]:" + selectedCastles.id);
                Console.Out.WriteLine("selectedCastles[castle_name]:" + selectedCastles.castle_name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
            {
                if (this.Commands == null)
                    return;
                CommandName.CommandNameInfo info = this.Commands[e.ItemIndex];
                this.selectedCommands = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedCommands[id]:" + selectedCommands.id);
                Console.Out.WriteLine("selectedCommands[name]:" + selectedCommands.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
            {
                if (this.GameTips == null)
                    return;
                GameTip.GameTipInfo info = this.GameTips[e.ItemIndex];
                this.selectedGameTips = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedGameTips[id]:" + selectedGameTips.id);
                Console.Out.WriteLine("selectedGameTips[tip]:" + selectedGameTips.tip);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
            {
                if (this.HuntingZones == null)
                    return;
                HuntingZone.HuntingZoneInfo info = this.HuntingZones[e.ItemIndex];
                this.selectedHuntingZones = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedHuntingZones[id]:" + selectedHuntingZones.id);
                Console.Out.WriteLine("selectedHuntingZones[name]:" + selectedHuntingZones.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
            {
                if (this.Items == null)
                    return;
                ItemName.ItemNameInfo info = this.Items[e.ItemIndex];
                this.selectedItems = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedItems[id]:" + selectedItems.id);
                Console.Out.WriteLine("selectedItems[name]:" + selectedItems.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
            {
                if (this.Npcs == null)
                    return;
                NpcName.NpcNameInfo info = this.Npcs[e.ItemIndex];
                this.selectedNpcs = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedNpcs[id]:" + selectedNpcs.id);
                Console.Out.WriteLine("selectedNpcs[name]:" + selectedNpcs.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
            {
                if (this.Obscenes == null)
                    return;
                Obscene.ObsceneInfo info = this.Obscenes[e.ItemIndex];
                this.selectedObscenes = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedObscenes[id]:" + selectedObscenes.id);
                Console.Out.WriteLine("selectedObscenes[text]:" + selectedObscenes.text);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
            {
                if (this.Quests == null)
                    return;
                QuestName.QuestNameInfo info = this.Quests[e.ItemIndex];
                this.selectedQuests = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedQuests[quest_id]:" + selectedQuests.quest_id);
                Console.Out.WriteLine("selectedQuests[quest_prog]:" + selectedQuests.quest_prog);
                Console.Out.WriteLine("selectedQuests[main_name]:" + selectedQuests.main_name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
            {
                if (this.Raids == null)
                    return;
                RaidData.RaidDataInfo info = this.Raids[e.ItemIndex];
                this.selectedRaids = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedRaids[id]:" + selectedRaids.id);
                Console.Out.WriteLine("selectedRaids[npc id]:" + selectedRaids.npc_id);
                Console.Out.WriteLine("selectedRaids[npc level]:" + selectedRaids.npc_level);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
            {
                if (this.Recipes == null)
                    return;
                Recipe.RecipeInfo info = this.Recipes[e.ItemIndex];
                this.selectedRecipes = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedRecipes[name]:" + selectedRecipes.name);
                Console.Out.WriteLine("selectedRecipes[id_recipe]:" + selectedRecipes.id_recipe);
                Console.Out.WriteLine("selectedRecipes[id_item]:" + selectedRecipes.id_item);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
            {
                if (this.Servers == null)
                    return;
                ServerName.ServerNameInfo info = this.Servers[e.ItemIndex];
                this.selectedServers = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedServers[server_id]:" + selectedServers.server_id);
                Console.Out.WriteLine("selectedServers[server_name]:" + selectedServers.server_name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
            {
                if (this.Skills == null)
                    return;
                SkillName.SkillNameInfo info = this.Skills[e.ItemIndex];
                this.selectedSkills = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedSkills[id]:" + selectedSkills.id);
                Console.Out.WriteLine("selectedSkills[level]:" + selectedSkills.level);
                Console.Out.WriteLine("selectedSkills[name]:" + selectedSkills.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
            {
                if (this.StaticObjects == null)
                    return;
                StaticObject.StaticObjectInfo info = this.StaticObjects[e.ItemIndex];
                this.selectedStaticObjects = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedStaticObjects[id]:" + selectedStaticObjects.id);
                Console.Out.WriteLine("selectedStaticObjects[name]:" + selectedStaticObjects.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
            {
                if (this.SysStrings == null)
                    return;
                SysString.SysStringInfo info = this.SysStrings[e.ItemIndex];
                this.selectedSysStrings = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedSysStrings[id]:" + selectedSysStrings.id);
                Console.Out.WriteLine("selectedSysStrings[name]:" + selectedSysStrings.name);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
            {
                if (this.SystemMsgs == null)
                    return;
                SystemMsg.SystemMsgInfo info = this.SystemMsgs[e.ItemIndex];
                this.selectedSystemMsgs = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedSystemMsgs[id]:" + selectedSystemMsgs.id);
                Console.Out.WriteLine("selectedSystemMsgs[message]:" + selectedSystemMsgs.msg);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
            {
                if (this.Weapongrps == null)
                    return;
                Weapongrp.WeapongrpInfo info = this.Weapongrps[e.ItemIndex];
                this.selectedWeapongrps = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedWeapongrps[id]:" + selectedWeapongrps.id);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
            {
                if (this.Zones == null)
                    return;
                ZoneName.ZoneNameInfo info = this.Zones[e.ItemIndex];
                this.selectedZones = info;
                this.selectedListsIndex = e.ItemIndex;
                Console.Out.WriteLine("<SELECT> List_Items:" + e.ItemIndex);
                Console.Out.WriteLine("selectedZones[nbr]:" + selectedZones.nbr);
                Console.Out.WriteLine("selectedZones[zone_name]:" + selectedZones.zone_name);
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Enabled = false;
            this.Config_Save();
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            this.List_Items.BeginUpdate();
            this.List_Items.Width = this.Width - 35;
            this.List_Items.Height = this.Height - 130;
            if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.30);
                this.List_Items.Columns[8].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.30);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.80);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.80);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.25);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[8].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.03);
                this.List_Items.Columns[9].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.50);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.30);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.80);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.45);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[8].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.80);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.30);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.30);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.80);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.80);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.35);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.15);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
            {
                this.List_Items.Columns[0].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.05);
                this.List_Items.Columns[1].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[2].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[3].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[4].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[5].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.10);
                this.List_Items.Columns[6].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.20);
                this.List_Items.Columns[7].Width = (int)Math.Round(this.List_Items.ClientSize.Width * 0.25);
            }
            this.List_Items.EndUpdate();
        }

        private void FileNameCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ListItems_Clear();
            this.List_Items.Columns.Clear();
            this.List_Items.Enabled = false;
            this.SaveBtn.Enabled = false;
            this.ExpBtn.Enabled = false;
            this.selectedListsIndex = 0;
            this.selectedComboName = this.FileNameCombo.Items[this.FileNameCombo.SelectedIndex].ToString();
            this.selectedComboIndex = this.FileNameCombo.SelectedIndex;
            if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
            {
                ColumnHeader[] columns = new ColumnHeader[9];
                ColumnsTitle = new String[9];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "Tag";
                columns[1].Text = "ID";
                columns[2].Text = "Type";
                columns[3].Text = "Category";
                columns[4].Text = "Cat2_IDs";
                columns[5].Text = "cmd";
                columns[6].Text = "Icon";
                columns[7].Text = "Name";
                columns[8].Text = "Desc";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
            {
                ColumnHeader[] columns = new ColumnHeader[6];
                ColumnsTitle = new String[6];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "NBR";
                columns[1].Text = "Tag";
                columns[2].Text = "ID";
                columns[3].Text = "CastleName";
                columns[4].Text = "Location";
                columns[5].Text = "Desc";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
            {
                ColumnHeader[] columns = new ColumnHeader[3];
                ColumnsTitle = new String[3];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "NBR";
                columns[1].Text = "ID";
                columns[2].Text = "Name";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
            {
                ColumnHeader[] columns = new ColumnHeader[5];
                ColumnsTitle = new String[5];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Tmp1";
                columns[2].Text = "Tmp2";
                columns[3].Text = "Enable";
                columns[4].Text = "Tip";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
            {
                ColumnHeader[] columns = new ColumnHeader[8];
                ColumnsTitle = new String[8];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "HuntingType";
                columns[2].Text = "Level";
                columns[3].Text = "LocX";
                columns[4].Text = "LocY";
                columns[5].Text = "LocZ";
                columns[6].Text = "AreaId";
                columns[7].Text = "RaidDesc";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
            {
                ColumnHeader[] columns = new ColumnHeader[10];
                ColumnsTitle = new String[10];
                for (int i=0;i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Name";
                columns[2].Text = "AdditionalName";
                columns[3].Text = "Description";
                columns[4].Text = "SetIds";
                columns[5].Text = "SetBonusDesc";
                columns[6].Text = "SetExtraId";
                columns[7].Text = "SetExtraDesc";
                columns[8].Text = "SpEnchantAmount";
                columns[9].Text = "SpEnchantDesc";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
            {
                ColumnHeader[] columns = new ColumnHeader[4];
                ColumnsTitle = new String[4];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Name";
                columns[2].Text = "Title";
                columns[3].Text = "RGB";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
            {
                ColumnHeader[] columns = new ColumnHeader[2];
                ColumnsTitle = new String[2];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Text";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
            {
                ColumnHeader[] columns = new ColumnHeader[8];
                ColumnsTitle = new String[8];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "Quest ID";
                columns[1].Text = "Quest Prog";
                columns[2].Text = "MainName";
                columns[3].Text = "ProgName";
                columns[4].Text = "Description";
                columns[5].Text = "EntityName";
                columns[6].Text = "RaceRestricion";
                columns[7].Text = "ShortDescription";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
            {
                ColumnHeader[] columns = new ColumnHeader[8];
                ColumnsTitle = new String[8];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "NPC ID";
                columns[2].Text = "NPC Level";
                columns[3].Text = "AreaId";
                columns[4].Text = "LocX";
                columns[5].Text = "LocY";
                columns[6].Text = "LocZ";
                columns[7].Text = "Name";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
            {
                ColumnHeader[] columns = new ColumnHeader[9];
                ColumnsTitle = new String[9];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "Name";
                columns[1].Text = "Mk ID";
                columns[2].Text = "Recipe ID";
                columns[3].Text = "Level";
                columns[4].Text = "Materials";
                columns[5].Text = "Item ID";
                columns[6].Text = "Count";
                columns[7].Text = "MP Cost";
                columns[8].Text = "SuccessRate";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
            {
                ColumnHeader[] columns = new ColumnHeader[2];
                ColumnsTitle = new String[2];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ServerID";
                columns[1].Text = "ServerName";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
            {
                ColumnHeader[] columns = new ColumnHeader[6];
                ColumnsTitle = new String[6];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Level";
                columns[2].Text = "Name";
                columns[3].Text = "Description";
                columns[4].Text = "DescAdd1";
                columns[5].Text = "DescAdd2";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
            {
                ColumnHeader[] columns = new ColumnHeader[2];
                ColumnsTitle = new String[2];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Name";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
            {
                ColumnHeader[] columns = new ColumnHeader[2];
                ColumnsTitle = new String[2];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Name";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
            {
                ColumnHeader[] columns = new ColumnHeader[8];
                ColumnsTitle = new String[8];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "ID";
                columns[1].Text = "Message";
                columns[2].Text = "Group";
                columns[3].Text = "RGB";
                columns[4].Text = "ItemSound";
                columns[5].Text = "SysMsgRef";
                columns[6].Text = "SubMsg";
                columns[7].Text = "Type";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
            {
                ColumnHeader[] columns = new ColumnHeader[87];
                ColumnsTitle = new String[87];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "tags";
                columns[1].Text = "id";
                columns[2].Text = "drop_type";
                columns[3].Text = "drop_anim_type";
                columns[4].Text = "drop_radius";
                columns[5].Text = "drop_height";
                columns[6].Text = "UNK_0";
                columns[7].Text = "drop_meshtex1";
                columns[8].Text = "drop_meshtex2";
                columns[9].Text = "icon1";
                columns[10].Text = "icon2";
                columns[11].Text = "icon3";
                columns[12].Text = "icon4";
                columns[13].Text = "icon5";
                columns[14].Text = "icon6";
                columns[15].Text = "icon7";
                columns[16].Text = "icon8";
                columns[17].Text = "icon9";
                columns[18].Text = "durability";
                columns[19].Text = "weight";
                columns[20].Text = "material";
                columns[21].Text = "crystallizable";
                columns[22].Text = "projectile";
                columns[23].Text = "UNK_1";
                columns[24].Text = "body_part";
                columns[25].Text = "handness";
                columns[26].Text = "cntm";
                columns[27].Text = "mesh";
                columns[28].Text = "cntt";
                columns[29].Text = "text";
                columns[30].Text = "item_sound_cnt";
                columns[31].Text = "item_sound";
                columns[32].Text = "drop_sound";
                columns[33].Text = "equip_sound";
                columns[34].Text = "effect";
                columns[35].Text = "random_damage";
                columns[36].Text = "patt";
                columns[37].Text = "matt";
                columns[38].Text = "weapon_type";
                columns[39].Text = "crystal_type";
                columns[40].Text = "critical";
                columns[41].Text = "hit_mod";
                columns[42].Text = "avoid_mod";
                columns[43].Text = "shield_pdef";
                columns[44].Text = "shield_rate";
                columns[45].Text = "speed";
                columns[46].Text = "mp_consume";
                columns[47].Text = "SS_count";
                columns[48].Text = "SPS_count";
                columns[49].Text = "curvature";
                columns[50].Text = "UNK_2";
                columns[51].Text = "is_hero";
                columns[52].Text = "UNK_3";
                columns[53].Text = "effA";
                columns[54].Text = "effB";
                columns[55].Text = "junk1A_1";
                columns[56].Text = "junk1A_2";
                columns[57].Text = "junk1A_3";
                columns[58].Text = "junk1A_4";
                columns[59].Text = "junk1A_5";
                columns[60].Text = "junk1B_1";
                columns[61].Text = "junk1B_2";
                columns[62].Text = "junk1B_3";
                columns[63].Text = "junk1B_4";
                columns[64].Text = "junk1B_5";
                columns[65].Text = "rangeA";
                columns[66].Text = "rangeB";
                columns[67].Text = "junk2A_1";
                columns[68].Text = "junk2A_2";
                columns[69].Text = "junk2A_3";
                columns[70].Text = "junk2A_4";
                columns[71].Text = "junk2A_5";
                columns[72].Text = "junk2A_6";
                columns[73].Text = "junk2B_1";
                columns[74].Text = "junk2B_2";
                columns[75].Text = "junk2B_3";
                columns[76].Text = "junk2B_4";
                columns[77].Text = "junk2B_5";
                columns[78].Text = "junk2B_6";
                columns[79].Text = "junk3_1";
                columns[80].Text = "junk3_2";
                columns[81].Text = "junk3_3";
                columns[82].Text = "junk3_4";
                columns[83].Text = "icons1";
                columns[84].Text = "icons2";
                columns[85].Text = "icons3";
                columns[86].Text = "icons4";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
            {
                ColumnHeader[] columns = new ColumnHeader[8];
                ColumnsTitle = new String[8];
                for (int i = 0; i < columns.Length; i++)
                    columns[i] = new ColumnHeader();
                columns[0].Tag = "";
                columns[0].Text = "NBR";
                columns[1].Text = "ZoneColorID";
                columns[2].Text = "X WorldGrid";
                columns[3].Text = "Y WorldGrid";
                columns[4].Text = "Top Z";
                columns[5].Text = "Bottom Z";
                columns[6].Text = "ZoneName";
                columns[7].Text = "MapName";
                for (int i = 0; i < columns.Length; i++)
                    ColumnsTitle[i] = columns[i].Text;
                this.List_Items.Columns.AddRange(columns);
            }

            this.LoadBtn.Enabled = true;
            this.ImpBtn.Enabled = true;
            this.ListItems_Update();
            this.MainForm_Resize(sender, e);
        }

        private void ListItems_Select()
        {
            if (List_Items.Items.Count > 0)
            {
                if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
                {
                    this.selectedActions = this.Actions[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
                {
                    this.selectedCastles = this.Castles[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
                {
                    this.selectedCommands = this.Commands[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
                {
                    this.selectedGameTips = this.GameTips[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
                {
                    this.selectedHuntingZones = this.HuntingZones[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
                {
                    this.selectedItems = this.Items[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
                {
                    this.selectedNpcs = this.Npcs[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
                {
                    this.selectedObscenes = this.Obscenes[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
                {
                    this.selectedQuests = this.Quests[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
                {
                    this.selectedRaids = this.Raids[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
                {
                    this.selectedRecipes = this.Recipes[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
                {
                    this.selectedServers = this.Servers[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
                {
                    this.selectedSkills = this.Skills[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
                {
                    this.selectedStaticObjects = this.StaticObjects[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
                {
                    this.selectedSysStrings = this.SysStrings[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
                {
                    this.selectedSystemMsgs = this.SystemMsgs[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
                {
                    this.selectedWeapongrps = this.Weapongrps[0];
                    List_Items.Items[0].Selected = true;
                }
                else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
                {
                    this.selectedZones = this.Zones[0];
                    List_Items.Items[0].Selected = true;
                }
            }
        }

        private void ListItems_Clear()
        {
            if (this.Actions != null)
            {
                this.Actions.Clear();
                this.Actions = null;
            }
            if (this.Castles != null)
            {
                this.Castles.Clear();
                this.Castles = null;
            }
            if (this.Commands != null)
            {
                this.Commands.Clear();
                this.Commands = null;
            }
            if (this.GameTips != null)
            {
                this.GameTips.Clear();
                this.GameTips = null;
            }
            if (this.HuntingZones != null)
            {
                this.HuntingZones.Clear();
                this.HuntingZones = null;
            }
            if (this.Items != null)
            {
                this.Items.Clear();
                this.Items = null;
            }
            if (this.Npcs != null)
            {
                this.Npcs.Clear();
                this.Npcs = null;
            }
            if (this.Obscenes!= null)
            {
                this.Obscenes.Clear();
                this.Obscenes = null;
            }
            if (this.Quests != null)
            {
                this.Quests.Clear();
                this.Quests = null;
            }
            if (this.Raids != null)
            {
                this.Raids.Clear();
                this.Raids = null;
            }
            if (this.Recipes != null)
            {
                this.Recipes.Clear();
                this.Recipes = null;
            }
            if (this.Servers != null)
            {
                this.Servers.Clear();
                this.Servers = null;
            }
            if (this.Skills != null)
            {
                this.Skills.Clear();
                this.Skills = null;
            }
            if (this.StaticObjects != null)
            {
                this.StaticObjects.Clear();
                this.StaticObjects = null;
            }
            if (this.SysStrings != null)
            {
                this.SysStrings.Clear();
                this.SysStrings = null;
            }
            if (this.SystemMsgs != null)
            {
                this.SystemMsgs.Clear();
                this.SystemMsgs = null;
            }
            if (this.Weapongrps != null)
            {
                this.Weapongrps.Clear();
                this.Weapongrps = null;
            }
            if (this.Zones != null)
            {
                this.Zones.Clear();
                this.Zones = null;
            }
            this.List_Items.Items.Clear();
        }

        private void ListItems_Update()
        {
            if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_actionname))
            {
                if (this.Actions != null)
                    this.List_Items.VirtualListSize = this.Actions.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
            {
                if (this.Castles != null)
                    this.List_Items.VirtualListSize = this.Castles.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
            {
                if (this.Commands != null)
                    this.List_Items.VirtualListSize = this.Commands.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
            {
                if (this.GameTips != null)
                    this.List_Items.VirtualListSize = this.GameTips.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
            {
                if (this.HuntingZones != null)
                    this.List_Items.VirtualListSize = this.HuntingZones.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
            {
                if (this.Items != null)
                    this.List_Items.VirtualListSize = this.Items.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
            {
                if (this.Npcs != null)
                    this.List_Items.VirtualListSize = this.Npcs.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
            {
                if (this.Obscenes != null)
                    this.List_Items.VirtualListSize = this.Obscenes.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_questname))
            {
                if (this.Quests != null)
                    this.List_Items.VirtualListSize = this.Quests.Count;
                else
                    this.List_Items.VirtualListSize = 0;
                // Not Support Save & Import
                this.SaveBtn.Enabled = false;
                this.ImpBtn.Enabled = false;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
            {
                if (this.Raids != null)
                    this.List_Items.VirtualListSize = this.Raids.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_recipe))
            {
                if (this.Recipes != null)
                    this.List_Items.VirtualListSize = this.Recipes.Count;
                else
                    this.List_Items.VirtualListSize = 0;
                // Not Support Save & Import
                this.SaveBtn.Enabled = false;
                this.ImpBtn.Enabled = false;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
            {
                if (this.Servers != null)
                    this.List_Items.VirtualListSize = this.Servers.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
            {
                if (this.Skills != null)
                    this.List_Items.VirtualListSize = this.Skills.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
            {
                if (this.StaticObjects != null)
                    this.List_Items.VirtualListSize = this.StaticObjects.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
            {
                if (this.SysStrings != null)
                    this.List_Items.VirtualListSize = this.SysStrings.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
            {
                if (this.SystemMsgs != null)
                    this.List_Items.VirtualListSize = this.SystemMsgs.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
            {
                if (this.Weapongrps != null)
                    this.List_Items.VirtualListSize = this.Weapongrps.Count;
                else
                    this.List_Items.VirtualListSize = 0;
            }
            else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_zonename))
            {
                if (this.Zones != null)
                    this.List_Items.VirtualListSize = this.Zones.Count;
                else
                    this.List_Items.VirtualListSize = 0;
                // Not Support Save & Import
                this.SaveBtn.Enabled = false;
                this.ImpBtn.Enabled = false;
            }
        }

        private void ExpBtn_Click(object sender, EventArgs e)
        {
            try
            {
                this.FileNameCombo.Enabled = false;
                this.List_Items.Enabled = false;
                this.Enabled = false;

                this.ExportDialog.InitialDirectory = Application.StartupPath;
                this.ExportDialog.FileName = this.selectedComboName.Substring(0, this.selectedComboName.LastIndexOf("."));
                this.ExportDialog.Filter = "CSV files (*.csv)|*.csv";
                this.ExportDialog.FilterIndex = 1;
                this.ExportDialog.RestoreDirectory = true;
                if (this.ExportDialog.ShowDialog() == DialogResult.OK)
                {
                    System.Text.Encoding enc = System.Text.Encoding.GetEncoding(Program.config.TextEncoding);
                    System.IO.StreamWriter sr = new System.IO.StreamWriter(this.ExportDialog.FileName, false, enc);
                    sr.Write("# ");
                    for (int i = 0; i < this.ColumnsTitle.Length; i++)
                    {
                        sr.Write(ColumnsTitle[i]);
                        if (i < this.ColumnsTitle.Length - 1)
                            sr.Write('\t');
                    }
                    sr.Write("\r\n");
                    for (int i = 0; i < this.List_Items.Items.Count; i++)
                    {
                        for (int j = 0; j < this.List_Items.Columns.Count; j++)
                        {
                            ListViewItem item = this.List_Items.Items[i];
                            string TmpStr = item.SubItems[j].Text;
                            if (TmpStr.IndexOf('"') > -1 ||
                                        TmpStr.IndexOf(',') > -1 ||
                                        TmpStr.IndexOf('\r') > -1 ||
                                        TmpStr.IndexOf('\n') > -1 ||
                                        TmpStr.StartsWith(" ") || TmpStr.StartsWith("\t") ||
                                        TmpStr.EndsWith(" ") || TmpStr.EndsWith("\t"))
                            {
                                if (TmpStr.IndexOf('"') > -1)
                                {
                                    TmpStr = TmpStr.Replace("\"", "\"\"");
                                }
                                TmpStr = "\"" + TmpStr + "\"";
                            }
                            sr.Write(TmpStr);
                            if (j < this.List_Items.Columns.Count-1)
                                sr.Write('\t');
                        }
                        sr.Write("\r\n");
                    }
                    sr.Close();
                }
                else
                    return;
            }
            catch (Exception ex)
            {
                Program.log.Add(ex, true);
            }
            finally
            {
                this.Enabled = true;
                this.FileNameCombo.Enabled = true;
                this.List_Items.Enabled = true;
            }
            System.Windows.Forms.MessageBox.Show("Complete.");
        }

        private void ImpBtn_Click(object sender, EventArgs e)
        {
            try
            {
                this.FileNameCombo.Enabled = false;
                this.List_Items.Enabled = false;
                this.Enabled = false;

                this.ImportDialog.InitialDirectory = Application.StartupPath;
                this.ImportDialog.FileName = this.selectedComboName.Substring(0, this.selectedComboName.LastIndexOf("."));
                this.ImportDialog.Filter = "CSV files (*.csv)|*.csv";
                this.ImportDialog.FilterIndex = 1;
                this.ImportDialog.RestoreDirectory = true;
                if (this.ImportDialog.ShowDialog() == DialogResult.OK)
                {
                    this.ListItems_Clear();
                    string line = "";
                    System.Text.Encoding enc = System.Text.Encoding.GetEncoding(Program.config.TextEncoding);
                    System.IO.StreamReader sr = new System.IO.StreamReader(this.ImportDialog.FileName, enc);

                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.StartsWith("#")) continue;
                        String[] TmpStr = line.Split(new char[] { '\t' });
                        if (TmpStr.Length != this.ColumnsTitle.Length)
                        {
                            sr.Close();
                            System.Windows.Forms.MessageBox.Show("The number of columns is not corresponding.");
                            return;
                        }
                        for (int i = 0; i < TmpStr.Length; i++)
                        {
                            TmpStr[i] = TmpStr[i].Trim(new char[] { '"' });
                        }

                        if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_castlename))
                        {
                            if (this.Castles == null)
                                this.Castles = new List<CastleName.CastleNameInfo>();
                            CastleName.CastleNameInfo info = new CastleName.CastleNameInfo();
                            info.nbr = Convert.ToInt32(TmpStr[0]);
                            info.tags = Convert.ToInt32(TmpStr[1]);
                            info.id = Convert.ToInt32(TmpStr[2]);
                            info.castle_name = TmpStr[3];
                            info.location = TmpStr[4];
                            info.desc = TmpStr[5];
                            this.Castles.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_commandname))
                        {
                            if (this.Commands == null)
                                this.Commands = new List<CommandName.CommandNameInfo>();
                            CommandName.CommandNameInfo info = new CommandName.CommandNameInfo();
                            info.nbr = Convert.ToInt32(TmpStr[0]);
                            info.id = Convert.ToInt32(TmpStr[1]);
                            info.name = TmpStr[2];
                            this.Commands.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_gametip))
                        {
                            if (this.GameTips == null)
                                this.GameTips = new List<GameTip.GameTipInfo>();
                            GameTip.GameTipInfo info = new GameTip.GameTipInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.tmp1 = Convert.ToInt32(TmpStr[1]);
                            info.tmp2 = Convert.ToInt32(TmpStr[2]);
                            info.enable = Convert.ToInt32(TmpStr[3]);
                            info.tip = TmpStr[4];
                            this.GameTips.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_huntingzone))
                        {
                            if (this.HuntingZones == null)
                                this.HuntingZones = new List<HuntingZone.HuntingZoneInfo>();
                            HuntingZone.HuntingZoneInfo info = new HuntingZone.HuntingZoneInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.hunting_type = Convert.ToInt32(TmpStr[1]);
                            info.level = Convert.ToInt32(TmpStr[2]);
                            info.loc_x = Convert.ToSingle(TmpStr[3]);
                            info.loc_y = Convert.ToSingle(TmpStr[4]);
                            info.loc_z = Convert.ToSingle(TmpStr[5]);
                            info.affiliated_area_id = Convert.ToInt32(TmpStr[6]);
                            info.name = TmpStr[7];
                            this.HuntingZones.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_itemname))
                        {
                            if (this.Items == null)
                                this.Items = new List<ItemName.ItemNameInfo>();
                            ItemName.ItemNameInfo info = new ItemName.ItemNameInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.name = TmpStr[1];
                            info.additionalname = TmpStr[2];
                            info.description = TmpStr[3];
                            info.popup = -1;
                            info.set_ids = TmpStr[4];
                            info.set_bonus_desc = TmpStr[5];
                            info.set_extra_id = TmpStr[6];
                            info.set_extra_desc = TmpStr[7];
                            info.special_enchant_amount = Convert.ToInt32(TmpStr[8]);
                            info.special_enchant_desc = TmpStr[9];
                            this.Items.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_npcname))
                        {
                            if (this.Npcs == null)
                                this.Npcs = new List<NpcName.NpcNameInfo>();
                            NpcName.NpcNameInfo info = new NpcName.NpcNameInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.name = TmpStr[1];
                            info.title = TmpStr[2];
                            info.ColorStr = TmpStr[3];
                            this.Npcs.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_obscene))
                        {
                            if (this.Obscenes == null)
                                this.Obscenes = new List<Obscene.ObsceneInfo>();
                            Obscene.ObsceneInfo info = new Obscene.ObsceneInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.text = TmpStr[1];
                            this.Obscenes.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_raiddata))
                        {
                            if (this.Raids == null)
                                this.Raids = new List<RaidData.RaidDataInfo>();
                            RaidData.RaidDataInfo info = new RaidData.RaidDataInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.npc_id = Convert.ToInt32(TmpStr[1]);
                            info.npc_level = Convert.ToInt32(TmpStr[2]);
                            info.affiliated_area_id = Convert.ToInt32(TmpStr[3]);
                            info.loc_x = Convert.ToSingle(TmpStr[4]);
                            info.loc_y = Convert.ToSingle(TmpStr[5]);
                            info.loc_z = Convert.ToSingle(TmpStr[6]);
                            info.raid_desc = TmpStr[7];
                            this.Raids.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_servername))
                        {
                            if (this.Servers == null)
                                this.Servers = new List<ServerName.ServerNameInfo>();
                            ServerName.ServerNameInfo info = new ServerName.ServerNameInfo();
                            info.server_id = Convert.ToInt32(TmpStr[0]);
                            info.tags = 1;
                            info.server_name = TmpStr[1];
                            this.Servers.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_skillname))
                        {
                            if (this.Skills == null)
                                this.Skills = new List<SkillName.SkillNameInfo>();
                            SkillName.SkillNameInfo info = new SkillName.SkillNameInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.level = Convert.ToInt32(TmpStr[1]);
                            info.name = TmpStr[2];
                            info.description = TmpStr[3];
                            info.desc_add1 = TmpStr[4];
                            info.desc_add2 = TmpStr[5];
                            this.Skills.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_staticobject))
                        {
                            if (this.StaticObjects == null)
                                this.StaticObjects = new List<StaticObject.StaticObjectInfo>();
                            StaticObject.StaticObjectInfo info = new StaticObject.StaticObjectInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.name = TmpStr[1];
                            this.StaticObjects.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_sysstring))
                        {
                            if (this.SysStrings == null)
                                this.SysStrings = new List<SysString.SysStringInfo>();
                            SysString.SysStringInfo info = new SysString.SysStringInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.name = TmpStr[1];
                            this.SysStrings.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_systemmsg))
                        {
                            if (this.SystemMsgs == null)
                                this.SystemMsgs = new List<SystemMsg.SystemMsgInfo>();
                            SystemMsg.SystemMsgInfo info = new SystemMsg.SystemMsgInfo();
                            info.id = Convert.ToInt32(TmpStr[0]);
                            info.msg = TmpStr[1];
                            info.group = Convert.ToUInt32(TmpStr[2]);
                            info.ColorStr = TmpStr[3];
                            info.sound = TmpStr[4];
                            info.msg_ref = TmpStr[5];
                            this.SystemMsgs.Add(info);
                        }
                        else if (this.selectedComboName == Path.GetFileName(Program.config.LineAge_weapongrp))
                        {
                            if (this.Weapongrps == null)
                                this.Weapongrps = new List<Weapongrp.WeapongrpInfo>();
                            Weapongrp.WeapongrpInfo info = new Weapongrp.WeapongrpInfo();
                            info.tags = Convert.ToInt32(TmpStr[0]);
                            info.id = Convert.ToInt32(TmpStr[1]);
                            info.drop_type = Convert.ToInt32(TmpStr[2]);
                            info.drop_anim_type = Convert.ToInt32(TmpStr[3]);
                            info.drop_radius = Convert.ToInt32(TmpStr[4]);
                            info.drop_height = Convert.ToInt32(TmpStr[5]);
                            info.UNK_0 = Convert.ToInt32(TmpStr[6]);
                            info.drop_meshtex1 = TmpStr[7];
                            info.drop_meshtex2 = TmpStr[8];
                            info.icon1 = TmpStr[9];
                            info.icon2 = TmpStr[10];
                            info.icon3 = TmpStr[11];
                            info.icon4 = TmpStr[12];
                            info.icon5 = TmpStr[13];
                            info.icon6 = TmpStr[14];
                            info.icon7 = TmpStr[15];
                            info.icon8 = TmpStr[16];
                            info.icon9 = TmpStr[17];
                            info.durability = Convert.ToInt32(TmpStr[18]);
                            info.weight = Convert.ToInt32(TmpStr[19]);
                            info.material = Convert.ToInt32(TmpStr[20]);
                            info.crystallizable = Convert.ToInt32(TmpStr[21]);
                            info.projectile = Convert.ToInt32(TmpStr[22]);
                            if (Program.main_form.selectedChronicleIdx == 5) 
                                info.UNK_1 = TmpStr[23];
                            info.body_part = Convert.ToInt32(TmpStr[24]);
                            info.handness = Convert.ToInt32(TmpStr[25]);
                            info.cntm = Convert.ToInt32(TmpStr[26]);
                            info.mesh = TmpStr[27];
                            info.cntt = Convert.ToInt32(TmpStr[28]);
                            info.text = TmpStr[29];
                            info.item_sound_cnt = Convert.ToInt32(TmpStr[30]);
                            info.item_sound = TmpStr[31];
                            info.drop_sound = TmpStr[32];
                            info.equip_sound = TmpStr[33];
                            info.effect = TmpStr[34];
                            info.random_damage = Convert.ToInt32(TmpStr[35]);
                            info.patt = Convert.ToInt32(TmpStr[36]);
                            info.matt = Convert.ToInt32(TmpStr[37]);
                            info.weapon_type = Convert.ToInt32(TmpStr[38]);
                            info.crystal_type = Convert.ToInt32(TmpStr[39]);
                            info.critical = Convert.ToInt32(TmpStr[40]);
                            info.hit_mod = Convert.ToInt32(TmpStr[41]);
                            info.avoid_mod = Convert.ToInt32(TmpStr[42]);
                            info.shield_pdef = Convert.ToInt32(TmpStr[43]);
                            info.shield_rate = Convert.ToInt32(TmpStr[44]);
                            info.speed = Convert.ToInt32(TmpStr[45]);
                            info.mp_consume = Convert.ToInt32(TmpStr[46]);
                            info.SS_count = Convert.ToInt32(TmpStr[47]);
                            info.SPS_count = Convert.ToInt32(TmpStr[48]);
                            info.curvature = Convert.ToInt32(TmpStr[49]);
                            info.UNK_2 = Convert.ToInt32(TmpStr[50]);
                            info.is_hero = Convert.ToInt32(TmpStr[51]);
                            info.UNK_3 = Convert.ToInt32(TmpStr[52]);
                            info.effA = TmpStr[53];
                            if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                                    (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                                info.effB = TmpStr[54];
                            info.junk1A_1 = Convert.ToSingle(TmpStr[55]);
                            info.junk1A_2 = Convert.ToSingle(TmpStr[56]);
                            info.junk1A_3 = Convert.ToSingle(TmpStr[57]);
                            info.junk1A_4 = Convert.ToSingle(TmpStr[58]);
                            info.junk1A_5 = Convert.ToSingle(TmpStr[59]);
                            if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                                    (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                            {
                                info.junk1B_1 = Convert.ToSingle(TmpStr[60]);
                                info.junk1B_2 = Convert.ToSingle(TmpStr[61]);
                                info.junk1B_3 = Convert.ToSingle(TmpStr[62]);
                                info.junk1B_4 = Convert.ToSingle(TmpStr[63]);
                                info.junk1B_5 = Convert.ToSingle(TmpStr[64]);
                            }
                            info.rangeA = TmpStr[65];
                            if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                                    (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                                info.rangeB = TmpStr[66];
                            info.junk2A_1 = Convert.ToSingle(TmpStr[67]);
                            info.junk2A_2 = Convert.ToSingle(TmpStr[68]);
                            info.junk2A_3 = Convert.ToSingle(TmpStr[69]);
                            info.junk2A_4 = Convert.ToSingle(TmpStr[70]);
                            info.junk2A_5 = Convert.ToSingle(TmpStr[71]);
                            info.junk2A_6 = Convert.ToSingle(TmpStr[72]);
                            if ((Program.main_form.selectedChronicleIdx == 3 && (info.weapon_type == 5 || info.weapon_type == 8) || 
                                    (Program.main_form.selectedChronicleIdx >= 4 && info.body_part == 14 && (info.handness == 3 || info.handness == 7))))
                            {
                                info.junk2B_1 = Convert.ToSingle(TmpStr[73]);
                                info.junk2B_2 = Convert.ToSingle(TmpStr[74]);
                                info.junk2B_3 = Convert.ToSingle(TmpStr[75]);
                                info.junk2B_4 = Convert.ToSingle(TmpStr[76]);
                                info.junk2B_5 = Convert.ToSingle(TmpStr[77]);
                                info.junk2B_6 = Convert.ToSingle(TmpStr[78]);
                            }
                            info.junk3_1 = Convert.ToInt32(TmpStr[79]);
                            info.junk3_2 = Convert.ToInt32(TmpStr[80]);
                            info.junk3_3 = Convert.ToInt32(TmpStr[81]);
                            info.junk3_4 = Convert.ToInt32(TmpStr[82]);
                            info.icons1 = TmpStr[83];
                            info.icons2 = TmpStr[84];
                            info.icons3 = TmpStr[85];
                            info.icons4 = TmpStr[86];
                            this.Weapongrps.Add(info);
                        }
                        else
                        {
                            sr.Close();
                            System.Windows.Forms.MessageBox.Show("It is a file not supported.");
                            return;
                        }
                    }
                    sr.Close();

                    this.SaveBtn.Enabled = true;
                    this.ExpBtn.Enabled = true;
                    this.ListItems_Update();
                    this.MainForm_Resize(sender, e);
                    this.ListItems_Select();
                }
                else
                    return;
            }
            catch (Exception ex)
            {
                Program.log.Add(ex, true);
            }
            finally
            {
                this.Enabled = true;
                this.FileNameCombo.Enabled = true;
                this.List_Items.Enabled = true;
            }
            System.Windows.Forms.MessageBox.Show("Complete.");
        }

        private void MenuChgFolder_Click(object sender, EventArgs e)
        {
            Program.config.LoadLastFolder(this.folder_browser_lineage_directory, "folder_browser_lineage_directory");
            if (this.folder_browser_lineage_directory.ShowDialog() == DialogResult.OK)
            {
                this.ListItems_Clear();
                Program.config.SaveLastFolder(this.folder_browser_lineage_directory, "folder_browser_lineage_directory");
                Program.config.LineAgeDirectory = this.folder_browser_lineage_directory.SelectedPath;
            }
            this.Text = Application.ProductName + " - " + Program.config.LineAgeDirectory;
            
            this.ListItems_Update();
            this.MainForm_Resize(sender, e);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (System.Windows.Forms.MessageBox.Show("Exit Application ?", Application.ProductName, 
                MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                e.Cancel = true;
                return;
            }
        }

        private void MenuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MenuAbout_Click(object sender, EventArgs e)
        {
            AboutForm dlg = new AboutForm();
            dlg.ShowDialog();
        }

        private void ChronicleSettingMenuItem_Click(object sender, EventArgs e)
        {
            this.ChrSetMenuItem1.Checked = false;
            this.ChrSetMenuItem2.Checked = false;
            this.ChrSetMenuItem3.Checked = false;
            this.ChrSetMenuItem4.Checked = false;
            this.ChrSetMenuItem5.Checked = false;
            if (sender == this.ChrSetMenuItem1)
            {
                this.ChrSetMenuItem1.Checked = true;
                selectedChronicleIdx = 1;
            }
            else if (sender == this.ChrSetMenuItem2)
            {
                this.ChrSetMenuItem2.Checked = true;
                selectedChronicleIdx = 2;
            }
            else if (sender == this.ChrSetMenuItem3)
            {
                this.ChrSetMenuItem3.Checked = true;
                selectedChronicleIdx = 3;
            }
            else if (sender == this.ChrSetMenuItem4)
            {
                this.ChrSetMenuItem4.Checked = true;
                selectedChronicleIdx = 4;
            }
            else if (sender == this.ChrSetMenuItem5)
            {
                this.ChrSetMenuItem5.Checked = true;
                selectedChronicleIdx = 5;
            }
        }
    }
}