The NSISArray HTML documentation can be found under NSIS\Docs\NSISArray.
Examples can be found under NSIS\Examples\NSISArray.