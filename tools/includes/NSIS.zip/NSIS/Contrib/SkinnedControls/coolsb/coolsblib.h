#ifndef _SUPERSCROLL_INCLUDED
#define _SUPERSCROLL_INCLUDED

#ifdef __cplusplus
extern "C"{
#endif

#include <windows.h>


#ifdef __cplusplus
}
#endif

#endif


























